package com.battleship;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** End-to-end REST tests over the real Spring context and H2 database. */
@SpringBootTest
@AutoConfigureMockMvc
class BattleshipApiTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper mapper;

    private long createGame(int size) throws Exception {
        MvcResult res = mvc.perform(post("/api/games")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"size\":" + size + "}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status", is("SETUP")))
                .andReturn();
        return mapper.readTree(res.getResponse().getContentAsString()).get("gameId").asLong();
    }

    private void addShip(long id, String ship, int size, int xA, int yA, int xB, int yB) throws Exception {
        String body = String.format(
                "{\"shipId\":\"%s\",\"size\":%d,\"xA\":%d,\"yA\":%d,\"xB\":%d,\"yB\":%d}",
                ship, size, xA, yA, xB, yB);
        mvc.perform(post("/api/games/" + id + "/ships")
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isCreated());
    }

    @Test
    void fullGameFlowOverRest() throws Exception {
        long id = createGame(6);
        addShip(id, "SH1", 2, 1, 5, 4, 4);
        addShip(id, "SH2", 2, 1, 1, 5, 2);

        // battlefield shows labelled cells
        mvc.perform(get("/api/games/" + id + "/battlefield"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size", is(6)));

        // play the game
        MvcResult res = mvc.perform(post("/api/games/" + id + "/start"))
                .andExpect(status().isOk())
                .andReturn();
        JsonNode json = mapper.readTree(res.getResponse().getContentAsString());
        String winner = json.get("winner").asText();
        assertTrue(winner.equals("PlayerA") || winner.equals("PlayerB"));
        assertTrue(json.get("turns").size() > 0);

        // game is now finished and persisted with a winner
        mvc.perform(get("/api/games/" + id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status", is("FINISHED")))
                .andExpect(jsonPath("$.winner", is(winner)));
    }

    @Test
    void overlappingShipReturns400() throws Exception {
        long id = createGame(6);
        addShip(id, "SH1", 2, 1, 5, 4, 4);
        String body = "{\"shipId\":\"SH2\",\"size\":2,\"xA\":1,\"yA\":5,\"xB\":4,\"yB\":4}"; // overlaps SH1
        mvc.perform(post("/api/games/" + id + "/ships")
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status", is(400)));
    }

    @Test
    void unknownGameReturns404() throws Exception {
        mvc.perform(get("/api/games/999999")).andExpect(status().isNotFound());
    }

    @Test
    void oddBoardSizeReturns400() throws Exception {
        mvc.perform(post("/api/games")
                        .contentType(MediaType.APPLICATION_JSON).content("{\"size\":5}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void cannotStartWithoutShips() throws Exception {
        long id = createGame(6);
        mvc.perform(post("/api/games/" + id + "/start"))
                .andExpect(status().isBadRequest());
    }
}
