package com.battleship.repository;

import com.battleship.entity.ShotEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ShotRepository extends JpaRepository<ShotEntity, Long> {

    List<ShotEntity> findByGameIdOrderByTurnNo(Long gameId);
}
