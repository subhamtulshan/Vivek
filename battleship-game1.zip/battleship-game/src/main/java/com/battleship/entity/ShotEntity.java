package com.battleship.entity;

import com.battleship.model.PlayerSide;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/** Audit record of a single missile fired during a game. */
@Entity
@Table(name = "shot")
public class ShotEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "game_id", nullable = false)
    private GameEntity game;

    @Column(name = "turn_no", nullable = false)
    private int turnNo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PlayerSide shooter;

    @Column(nullable = false)
    private int x;

    @Column(nullable = false)
    private int y;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Outcome outcome;

    @Column(name = "destroyed_ship_id")
    private String destroyedShipId;

    protected ShotEntity() {
    }

    public ShotEntity(GameEntity game, int turnNo, PlayerSide shooter,
                      int x, int y, Outcome outcome, String destroyedShipId) {
        this.game = game;
        this.turnNo = turnNo;
        this.shooter = shooter;
        this.x = x;
        this.y = y;
        this.outcome = outcome;
        this.destroyedShipId = destroyedShipId;
    }

    public Long getId() {
        return id;
    }

    public int getTurnNo() {
        return turnNo;
    }

    public PlayerSide getShooter() {
        return shooter;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Outcome getOutcome() {
        return outcome;
    }

    public String getDestroyedShipId() {
        return destroyedShipId;
    }
}
