package com.battleship.entity;

/** Result of a single shot, persisted per turn. */
public enum Outcome {
    HIT,
    MISS
}
