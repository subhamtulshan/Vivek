package com.battleship.entity;

/** Lifecycle of a persisted game. */
public enum GameStatus {
    SETUP,     // created; ships can still be added
    FINISHED   // startGame has run; a winner is decided
}
