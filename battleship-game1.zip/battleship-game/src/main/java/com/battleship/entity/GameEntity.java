package com.battleship.entity;

import com.battleship.model.PlayerSide;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.ArrayList;
import java.util.List;

/** A persisted game: its size, status, winner and fleet. */
@Entity
@Table(name = "game")
public class GameEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private int size;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private GameStatus status = GameStatus.SETUP;

    @Enumerated(EnumType.STRING)
    private PlayerSide winner;

    @OneToMany(mappedBy = "game", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ShipEntity> ships = new ArrayList<>();

    protected GameEntity() {
    }

    public GameEntity(int size) {
        this.size = size;
    }

    public Long getId() {
        return id;
    }

    public int getSize() {
        return size;
    }

    public GameStatus getStatus() {
        return status;
    }

    public void setStatus(GameStatus status) {
        this.status = status;
    }

    public PlayerSide getWinner() {
        return winner;
    }

    public void setWinner(PlayerSide winner) {
        this.winner = winner;
    }

    public List<ShipEntity> getShips() {
        return ships;
    }

    public void addShip(ShipEntity ship) {
        ship.setGame(this);
        ships.add(ship);
    }
}
