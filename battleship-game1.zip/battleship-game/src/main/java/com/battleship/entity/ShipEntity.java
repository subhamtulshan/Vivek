package com.battleship.entity;

import com.battleship.model.PlayerSide;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/** A ship as stored in the DB (center + size + owner + destroyed flag). */
@Entity
@Table(name = "ship", uniqueConstraints =
        @UniqueConstraint(columnNames = {"game_id", "owner", "ship_id"}))
public class ShipEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "game_id", nullable = false)
    private GameEntity game;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PlayerSide owner;

    @Column(name = "ship_id", nullable = false)
    private String shipId;

    @Column(nullable = false)
    private int size;

    @Column(name = "center_x", nullable = false)
    private int centerX;

    @Column(name = "center_y", nullable = false)
    private int centerY;

    @Column(nullable = false)
    private boolean destroyed;

    protected ShipEntity() {
    }

    public ShipEntity(PlayerSide owner, String shipId, int size, int centerX, int centerY) {
        this.owner = owner;
        this.shipId = shipId;
        this.size = size;
        this.centerX = centerX;
        this.centerY = centerY;
    }

    public Long getId() {
        return id;
    }

    public GameEntity getGame() {
        return game;
    }

    public void setGame(GameEntity game) {
        this.game = game;
    }

    public PlayerSide getOwner() {
        return owner;
    }

    public String getShipId() {
        return shipId;
    }

    public int getSize() {
        return size;
    }

    public int getCenterX() {
        return centerX;
    }

    public int getCenterY() {
        return centerY;
    }

    public boolean isDestroyed() {
        return destroyed;
    }

    public void setDestroyed(boolean destroyed) {
        this.destroyed = destroyed;
    }
}
