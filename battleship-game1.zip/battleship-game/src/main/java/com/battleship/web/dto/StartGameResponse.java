package com.battleship.web.dto;

import java.util.List;

/** Result of playing a game: the full turn log and the winner. */
public record StartGameResponse(Long gameId, String winner, List<TurnResponse> turns) {
}
