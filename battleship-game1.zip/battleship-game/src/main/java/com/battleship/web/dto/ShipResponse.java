package com.battleship.web.dto;

import com.battleship.entity.ShipEntity;

/** A ship as returned to clients. */
public record ShipResponse(String owner, String shipId, int size, int x, int y, boolean destroyed) {

    public static ShipResponse from(ShipEntity s) {
        return new ShipResponse(s.getOwner().getDisplayName(), s.getShipId(),
                s.getSize(), s.getCenterX(), s.getCenterY(), s.isDestroyed());
    }
}
