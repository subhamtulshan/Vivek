package com.battleship.web.dto;

import com.battleship.entity.GameEntity;

import java.util.List;

/** Summary of a game's current state. */
public record GameResponse(Long gameId, int size, String status, String winner, List<ShipResponse> ships) {

    public static GameResponse from(GameEntity game) {
        List<ShipResponse> ships = game.getShips().stream()
                .map(ShipResponse::from)
                .toList();
        return new GameResponse(
                game.getId(),
                game.getSize(),
                game.getStatus().name(),
                game.getWinner() == null ? null : game.getWinner().getDisplayName(),
                ships);
    }
}
