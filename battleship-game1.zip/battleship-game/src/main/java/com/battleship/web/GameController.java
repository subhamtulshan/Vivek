package com.battleship.web;

import com.battleship.entity.GameEntity;
import com.battleship.service.GameService;
import com.battleship.web.dto.AddShipRequest;
import com.battleship.web.dto.BattlefieldResponse;
import com.battleship.web.dto.CreateGameRequest;
import com.battleship.web.dto.GameResponse;
import com.battleship.web.dto.StartGameResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** REST facade over the game operations. */
@RestController
@RequestMapping("/api/games")
public class GameController {

    private final GameService gameService;

    public GameController(GameService gameService) {
        this.gameService = gameService;
    }

    /** initGame(N) */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public GameResponse createGame(@Valid @RequestBody CreateGameRequest request) {
        return GameResponse.from(gameService.createGame(request.size()));
    }

    /** addShip(id, size, xA, yA, xB, yB) */
    @PostMapping("/{gameId}/ships")
    @ResponseStatus(HttpStatus.CREATED)
    public GameResponse addShip(@PathVariable Long gameId, @Valid @RequestBody AddShipRequest request) {
        GameEntity game = gameService.addShip(gameId, request.shipId(), request.size(),
                request.xA(), request.yA(), request.xB(), request.yB());
        return GameResponse.from(game);
    }

    /** startGame() */
    @PostMapping("/{gameId}/start")
    public StartGameResponse startGame(@PathVariable Long gameId) {
        return gameService.startGame(gameId);
    }

    /** viewBattleField() */
    @GetMapping("/{gameId}/battlefield")
    public BattlefieldResponse battlefield(@PathVariable Long gameId) {
        return gameService.battlefield(gameId);
    }

    /** Current game state. */
    @GetMapping("/{gameId}")
    public ResponseEntity<GameResponse> getGame(@PathVariable Long gameId) {
        return ResponseEntity.ok(GameResponse.from(gameService.getGame(gameId)));
    }
}
