package com.battleship.web;

import com.battleship.BattleshipException;
import com.battleship.service.GameNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/** Translates domain/rule violations into clean HTTP responses. */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /** Rule violations (overlap, out of bounds, already finished, ...) -> 400. */
    @ExceptionHandler(BattleshipException.class)
    public ResponseEntity<Map<String, Object>> handleRule(BattleshipException ex) {
        return build(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

    /** Unknown game id -> 404. */
    @ExceptionHandler(GameNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(GameNotFoundException ex) {
        return build(HttpStatus.NOT_FOUND, ex.getMessage());
    }

    /** Bean-validation failures on request bodies -> 400. */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidation(MethodArgumentNotValidException ex) {
        String msg = ex.getBindingResult().getFieldErrors().stream()
                .findFirst()
                .map(fe -> fe.getField() + " " + fe.getDefaultMessage())
                .orElse("Invalid request");
        return build(HttpStatus.BAD_REQUEST, msg);
    }

    private ResponseEntity<Map<String, Object>> build(HttpStatus status, String message) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", Instant.now().toString());
        body.put("status", status.value());
        body.put("error", status.getReasonPhrase());
        body.put("message", message);
        return ResponseEntity.status(status).body(body);
    }
}
