package com.battleship.web.dto;

/** One turn in the startGame result. */
public record TurnResponse(
        int turn,
        String shooter,
        int x,
        int y,
        String result,          // "Hit" or "Miss"
        String destroyedShip,   // e.g. "B-SH1", or null
        int aliveShipsPlayerA,
        int aliveShipsPlayerB) {
}
