package com.battleship.web.dto;

import jakarta.validation.constraints.Min;

/** Body for POST /api/games — the battlefield size N. */
public record CreateGameRequest(@Min(2) int size) {
}
