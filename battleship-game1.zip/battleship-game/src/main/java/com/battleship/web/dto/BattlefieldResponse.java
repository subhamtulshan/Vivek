package com.battleship.web.dto;

import java.util.List;

/** The battlefield grid, top row first (y = N-1 .. 0), each cell "A-SH1" / "B-SH2" / ".". */
public record BattlefieldResponse(Long gameId, int size, List<List<String>> grid) {
}
