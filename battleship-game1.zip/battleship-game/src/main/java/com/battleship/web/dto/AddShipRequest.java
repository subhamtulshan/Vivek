package com.battleship.web.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

/** Body for POST /api/games/{id}/ships — mirrors addShip(id, size, xA, yA, xB, yB). */
public record AddShipRequest(
        @NotBlank String shipId,
        @Min(1) int size,
        int xA, int yA,
        int xB, int yB) {
}
