package com.battleship.service;

/** Thrown when a game id does not exist — mapped to HTTP 404. */
public class GameNotFoundException extends RuntimeException {
    public GameNotFoundException(Long id) {
        super("Game " + id + " not found");
    }
}
