package com.battleship.service;

import com.battleship.BattleshipException;
import com.battleship.entity.GameEntity;
import com.battleship.entity.GameStatus;
import com.battleship.entity.Outcome;
import com.battleship.entity.ShipEntity;
import com.battleship.entity.ShotEntity;
import com.battleship.model.Board;
import com.battleship.model.Coordinate;
import com.battleship.model.Player;
import com.battleship.model.PlayerSide;
import com.battleship.model.Ship;
import com.battleship.model.ShipFactory;
import com.battleship.model.ShipType;
import com.battleship.repository.GameRepository;
import com.battleship.repository.ShotRepository;
import com.battleship.strategy.FireStrategy;
import com.battleship.web.dto.BattlefieldResponse;
import com.battleship.web.dto.StartGameResponse;
import com.battleship.web.dto.TurnResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service layer: orchestrates the four game operations. It persists state via JPA and, for
 * placement/firing, rebuilds the pure in-memory {@link Board}/{@link Ship} domain so all game
 * rules live in one place. Depends on the {@link FireStrategy} abstraction (injected).
 */
@Service
public class GameService {

    private final GameRepository gameRepository;
    private final ShotRepository shotRepository;
    private final FireStrategy fireStrategy;
    private final ShipFactory shipFactory = new ShipFactory();

    public GameService(GameRepository gameRepository,
                       ShotRepository shotRepository,
                       FireStrategy fireStrategy) {
        this.gameRepository = gameRepository;
        this.shotRepository = shotRepository;
        this.fireStrategy = fireStrategy;
    }

    /** initGame(N): create an NxN game. */
    @Transactional
    public GameEntity createGame(int size) {
        if (size <= 0 || size % 2 != 0) {
            throw new BattleshipException("Board size N must be a positive even number, got " + size);
        }
        return gameRepository.save(new GameEntity(size));
    }

    /** addShip(...): add an equal square ship to both fleets, after validating placement. */
    @Transactional
    public GameEntity addShip(Long gameId, String shipId, int size, int xA, int yA, int xB, int yB) {
        GameEntity game = load(gameId);
        if (game.getStatus() != GameStatus.SETUP) {
            throw new BattleshipException("Cannot add ships to a game that has already started");
        }

        // Rebuild both boards from existing ships and attempt placement — this reuses the
        // domain's overlap / out-of-bounds / duplicate-id validation.
        Board boardA = buildBoard(game, PlayerSide.PLAYER_A, new HashMap<>());
        Board boardB = buildBoard(game, PlayerSide.PLAYER_B, new HashMap<>());
        boardA.placeShip(shipFactory.create(ShipType.SQUARE, shipId, size, new Coordinate(xA, yA)));
        boardB.placeShip(shipFactory.create(ShipType.SQUARE, shipId, size, new Coordinate(xB, yB)));

        game.addShip(new ShipEntity(PlayerSide.PLAYER_A, shipId, size, xA, yA));
        game.addShip(new ShipEntity(PlayerSide.PLAYER_B, shipId, size, xB, yB));
        return gameRepository.save(game);
    }

    /** startGame(): play the whole game, persist every shot, record the winner. */
    @Transactional
    public StartGameResponse startGame(Long gameId) {
        GameEntity game = load(gameId);
        if (game.getStatus() == GameStatus.FINISHED) {
            throw new BattleshipException("Game " + gameId + " has already finished");
        }
        if (game.getShips().isEmpty()) {
            throw new BattleshipException("Cannot start: no ships added");
        }

        Map<String, Ship> shipsA = new HashMap<>();
        Map<String, Ship> shipsB = new HashMap<>();
        Player playerA = new Player(PlayerSide.PLAYER_A, buildBoard(game, PlayerSide.PLAYER_A, shipsA));
        Player playerB = new Player(PlayerSide.PLAYER_B, buildBoard(game, PlayerSide.PLAYER_B, shipsB));

        List<TurnResponse> turns = new ArrayList<>();
        List<ShotEntity> shots = new ArrayList<>();
        Player current = playerA;
        Player opponent = playerB;
        PlayerSide winner = null;
        int turnNo = 0;

        while (true) {
            Board oppBoard = opponent.getBoard();
            Coordinate target = fireStrategy.selectTarget(oppBoard);
            Ship destroyed = oppBoard.receiveFire(target);
            turnNo++;

            Outcome outcome = destroyed != null ? Outcome.HIT : Outcome.MISS;
            String destroyedLabel = destroyed == null ? null
                    : current.getSide().opponent().getPrefix() + "-" + destroyed.getId();

            shots.add(new ShotEntity(game, turnNo, current.getSide(),
                    target.getX(), target.getY(), outcome, destroyed == null ? null : destroyed.getId()));
            turns.add(new TurnResponse(turnNo, current.getName(), target.getX(), target.getY(),
                    outcome == Outcome.HIT ? "Hit" : "Miss", destroyedLabel,
                    playerA.aliveShips(), playerB.aliveShips()));

            if (opponent.hasLost()) {
                winner = current.getSide();
                break;
            }
            Player tmp = current;
            current = opponent;
            opponent = tmp;
        }

        // Persist results: shots, ship destroyed-flags, winner + status.
        shotRepository.saveAll(shots);
        for (ShipEntity e : game.getShips()) {
            Ship dom = (e.getOwner() == PlayerSide.PLAYER_A ? shipsA : shipsB).get(e.getShipId());
            e.setDestroyed(dom.isDestroyed());
        }
        game.setWinner(winner);
        game.setStatus(GameStatus.FINISHED);
        gameRepository.save(game);

        return new StartGameResponse(gameId, winner.getDisplayName(), turns);
    }

    /** viewBattleField(): grid with each occupied cell labelled A-SHx / B-SHx. */
    @Transactional(readOnly = true)
    public BattlefieldResponse battlefield(Long gameId) {
        GameEntity game = load(gameId);
        int n = game.getSize();
        int half = n / 2;
        Board boardA = buildBoard(game, PlayerSide.PLAYER_A, new HashMap<>());
        Board boardB = buildBoard(game, PlayerSide.PLAYER_B, new HashMap<>());

        List<List<String>> grid = new ArrayList<>();
        for (int y = n - 1; y >= 0; y--) {
            List<String> row = new ArrayList<>();
            for (int x = 0; x < n; x++) {
                Board board = (x < half) ? boardA : boardB;
                Ship ship = board.shipAt(new Coordinate(x, y));
                row.add(ship == null ? "." : board.getSide().getPrefix() + "-" + ship.getId());
            }
            grid.add(row);
        }
        return new BattlefieldResponse(gameId, n, grid);
    }

    @Transactional(readOnly = true)
    public GameEntity getGame(Long gameId) {
        GameEntity game = load(gameId);
        game.getShips().size(); // touch lazy collection inside the transaction
        return game;
    }

    private GameEntity load(Long id) {
        return gameRepository.findById(id).orElseThrow(() -> new GameNotFoundException(id));
    }

    /** Reconstructs a player's {@link Board} from persisted ships; fills {@code shipsById}. */
    private Board buildBoard(GameEntity game, PlayerSide side, Map<String, Ship> shipsById) {
        int n = game.getSize();
        int half = n / 2;
        int minX = (side == PlayerSide.PLAYER_A) ? 0 : half;
        int maxX = (side == PlayerSide.PLAYER_A) ? half - 1 : n - 1;
        Board board = new Board(side, minX, maxX, 0, n - 1);
        for (ShipEntity e : game.getShips()) {
            if (e.getOwner() == side) {
                Ship ship = shipFactory.create(ShipType.SQUARE, e.getShipId(), e.getSize(),
                        new Coordinate(e.getCenterX(), e.getCenterY()));
                board.placeShip(ship);
                shipsById.put(e.getShipId(), ship);
            }
        }
        return board;
    }
}
