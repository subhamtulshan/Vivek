package com.battleship;

import com.battleship.strategy.FireStrategy;
import com.battleship.strategy.RandomFireStrategy;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BattleshipApplication {

    public static void main(String[] args) {
        SpringApplication.run(BattleshipApplication.class, args);
    }

    /** The default fire strategy, injected wherever a {@link FireStrategy} is needed (DIP). */
    @Bean
    public FireStrategy fireStrategy() {
        return new RandomFireStrategy();
    }
}
