# Battleship — Design Doc (interview cheat-sheet)

## 0. Shape of the solution
A **Spring Boot REST API** backed by a **relational DB (H2 + JPA/Hibernate)**, wrapping a
**pure OOP domain**. The four spec APIs are HTTP endpoints under `/api/games`; every game, ship
and shot is persisted. The domain (rules + geometry) has **no framework dependency**, so the same
core could run behind a CLI or a different transport.

```
web         GameController + DTOs + GlobalExceptionHandler   (HTTP only)
service     GameService (4 ops, turn loop, @Transactional)
persistence GameEntity / ShipEntity / ShotEntity + JpaRepositories
domain      Board, Ship, Player, Coordinate, PlayerSide       (rules, no Spring)
support     FireStrategy/RandomFireStrategy, ShipFactory/ShipType, BattleshipException
```

**Key move:** `GameService` **rebuilds the in-memory `Board`/`Ship` domain from persisted rows**
to validate placement and play the game, then writes results back. Rules live in exactly one place
and stay unit-testable without Spring/DB.

## 1. Problem in one line
Two players, an N×N sea split in half; each fires random missiles at the opponent's half every
turn (no coordinate twice); one hit destroys a square ship; lose all ships = lose the game.
APIs: `initGame(N)`, `addShip(...)`, `startGame()`, `viewBattleField()` — exposed as REST.

## 2. Key modelling decisions (say these out loud)
- **Coordinate = a cell** `(x=col, y=row)`, zero-based, immutable value object (equals/hashCode →
  usable as a map/set key).
- **Ship position `(x,y)` = the ship's *center vertex*.** A size-`s` square covers an `s×s` block
  of cells whose lower-left cell is `(x - s/2, y - s/2)`.
  - Reconciles both spec examples: center (2,2) size 4 → cells (0,0)..(3,3); center (1,5) size 2 →
    {(0,4),(1,4),(0,5),(1,5)}. This was the trickiest ambiguity — call it out.
- **Board split:** left `N/2` columns `x∈[0,N/2-1]` = PlayerA, right `x∈[N/2,N-1]` = PlayerB.
  N must be positive & even.
- **One hit destroys the whole ship** (spec), so I don't track per-cell damage — just a
  `cellToShip` index + a `destroyed` flag.
- **"No coordinate fired twice"** → each Board keeps a `remainingTargets` pool; the strategy only
  ever picks from it, so uniqueness is structural, not a re-roll loop.

## 3. Class responsibilities (SRP)
| Class | Layer | Responsibility |
|---|---|---|
| `Coordinate` | domain | immutable cell (x,y) |
| `PlayerSide` (enum) | domain | A/B + display name + label prefix + `opponent()` |
| `Ship` | domain | id, size, computed occupied cells, destroyed flag |
| `Board` | domain | one half: place ships (validate), receive fire, target pool, alive count |
| `Player` | domain | a side + its board |
| `FireStrategy` / `RandomFireStrategy` | support | how to pick the next target (Strategy) |
| `ShipFactory` / `ShipType` | support | create ships (Factory) |
| `BattleshipException` | support | one type for all rule violations → HTTP 400 |
| `GameEntity`/`ShipEntity`/`ShotEntity` | persistence | JPA @Entities (game/ship/shot rows) |
| `GameRepository`/`ShotRepository` | persistence | Spring Data `JpaRepository` |
| `GameService` | service | the 4 ops + turn loop, `@Transactional`, rebuild-domain-from-rows |
| `GameController` + DTOs | web | REST endpoints, request validation, response mapping |
| `GlobalExceptionHandler` | web | maps exceptions → 400/404 JSON |

Clean **web ↔ service ↔ persistence ↔ domain** split: domain holds rules, service orchestrates +
transactions, persistence stores state, web is HTTP-only. No rules in the controller, no HTTP in
the domain.

## 3b. Persistence model (DB)
| Table | Key columns | Notes |
|---|---|---|
| `game` | id, size, status(`SETUP`/`FINISHED`), winner | one per game |
| `ship` | id, game_id, owner, ship_id, size, center_x/y, destroyed | unique `(game_id,owner,ship_id)` |
| `shot` | id, game_id, turn_no, shooter, x, y, outcome(`HIT`/`MISS`), destroyed_ship_id | replayable log |

`GameEntity` `@OneToMany` ships (cascade + orphanRemoval); shots persisted in one `saveAll` batch.
Swap H2 → Postgres/MySQL by changing only `application.yml` + the JDBC driver (DIP at the DB layer).

## 4. Patterns (only what's needed)
- **Strategy — `FireStrategy`.** Spec explicitly wants pluggable fire strategies; injected as a
  Spring `@Bean`. `GameService` depends on the interface, so a new strategy drops in with **zero**
  service changes.
- **Factory — `ShipFactory` + `ShipType`.** Centralizes construction; a new ship shape is added in
  one place. Rest of the code depends only on `Ship`.
- **Facade / layering — `GameController` → `GameService` → domain.** Each layer hides the next.
- **Repository — Spring Data `JpaRepository`.** Persistence abstracted from the service.

## 5. SOLID mapping
- **S** — each class one job (table above): HTTP / flow / persistence / rules separated.
- **O** — new strategy / ship shape / DB vendor without editing existing logic.
- **L** — any `FireStrategy` substitutes the interface.
- **I** — `FireStrategy` single-method; repositories expose only what's used.
- **D** — service depends on abstractions (`FireStrategy`, repositories) injected via constructor;
  a **seeded `Random`** makes domain tests deterministic.

## 6. Game flow (`POST /{id}/start` → `GameService.startGame`)
```
load GameEntity; rebuild Board/Ship domain for A and B from persisted ships
current=A, opponent=B, turnNo=0
loop:
  target   = fireStrategy.selectTarget(opponent.board)   // from remainingTargets
  destroyed= opponent.board.receiveFire(target)           // marks fired, returns ship or null
  record TurnResponse + build ShotEntity (turnNo, shooter, x, y, HIT/MISS)
  if opponent.hasLost(): winner=current; break
  swap(current, opponent)
persist: shotRepository.saveAll(shots); set ship.destroyed flags; game.winner; status=FINISHED
return StartGameResponse(winner, turns)
```

## 7. Rules & edge cases handled (→ HTTP status)
- Ship fully inside its half; **no overlap**; touching allowed; unique id per fleet → 400 on violation.
- Firing an already-fired cell → exception (never happens via strategy, but Board guards it).
- Odd/negative N (bean-validation + service check), `addShip` after start, `startGame` with no ships,
  already-finished game → 400. Unknown game id → 404.
- Termination guaranteed: every hit destroys a ship and cells are finite, so a player runs out.

## 8. Complexity
- `addShip`: O(s²) cells. `receiveFire`: O(1) hit lookup (map) + O(T) remove from target list.
- Memory: O(N²) for the target pools + O(total ship cells). DB writes: shots in one `saveAll` batch.
- (Optimization option: swap the target `List` for index-based swap-remove to make removal O(1).)

## 9. Tests (9)
- `BattleshipApiTest` (5) — `@SpringBootTest` + MockMvc against real H2: full REST flow ends with a
  persisted winner + `FINISHED`; overlap→400; unknown game→404; odd size→400; start-without-ships→400.
- `DomainTest` (4) — ship geometry (both examples), placement/overlap/bounds/duplicate-id,
  hit-destroys + duplicate-fire rejected, target pool shrinks.
- Determinism via seeded `Random` in the domain tests.

---

## 10. What else could be done (extensions — mention, don't build)
**Gameplay / rules**
- **Smarter strategies** via the same `FireStrategy` interface: *Hunt/Target* (after a hit, probe
  neighbours), *Parity/Checkerboard*, *Probability-density* targeting.
- **Non-square ships** (rectangle/line): make `Ship` an interface + `AbstractShip` (Template Method),
  add subclasses, extend `ShipType` — no change to `Board`/`Game`.
- **Partial damage**: track hit cells per ship; "destroyed only when all cells hit" (change one method).
- **Human player / mixed players**: extract a `Player` strategy (input source) so human vs bot works.

**Architecture / quality**
- **Turn-by-turn REST**: replace auto-play `start` with `POST /{id}/fire`, persisting state each
  turn (enables human vs bot, pause/resume). The `shot` table already records full history.
- **Observer / websockets** for live updates: `GameEventListener` → push turns to clients.
- **Prod DB + migrations**: Postgres/MySQL via `application.yml` + Flyway/Liquibase (H2 is dev-only).
- **Builder** for game setup (fluent `addShip` chaining, config object).
- **Immutability / thread-safety** if turns run concurrently; optimistic locking (`@Version`).

**Robustness / product**
- Auth (per-player games), rate limiting, OpenAPI/Swagger docs, pagination on history.
- Metrics/logging (shots fired, hit rate), seedable games for reproducible bug reports.
- More tests: property-based (no overlap ever), full-board exhaustion, large-N performance.
