# Battleship Game — Spring Boot REST API + Database

An interview-ready Battleship service. A **pure OOP domain** (rules, geometry, patterns) sits
behind a thin **Spring Boot REST layer** and is persisted in a **relational DB** (H2, JPA/Hibernate).
The four game operations are exposed as HTTP endpoints; every game, ship and shot is stored.

## Run

```bash
mvn test                 # 9 tests (5 REST + 4 domain)
mvn spring-boot:run      # starts on http://localhost:8080
```

H2 console (inspect the tables live): `http://localhost:8080/h2-console`
JDBC URL `jdbc:h2:mem:battleship`, user `sa`, empty password.

## REST API (`/api/games`)

| Verb & path | Maps to spec API | Body / result |
|---|---|---|
| `POST /api/games` | `initGame(N)` | `{"size":6}` → **201** `GameResponse` (status `SETUP`). N positive & even. |
| `POST /api/games/{id}/ships` | `addShip(id,size,xA,yA,xB,yB)` | `{"shipId":"SH1","size":2,"xA":1,"yA":5,"xB":4,"yB":4}` → **201**. Equal square ship added to both fleets after bounds/overlap/duplicate validation. |
| `POST /api/games/{id}/start` | `startGame()` | **200** `StartGameResponse` — winner + full turn-by-turn log; game persisted as `FINISHED`. |
| `GET  /api/games/{id}/battlefield` | `viewBattleField()` | **200** grid; occupied cells labelled `A-SH1` / `B-SH2`. |
| `GET  /api/games/{id}` | — | **200** current `GameResponse` (state + ships). |

### Quick demo (curl)

```bash
curl -sX POST localhost:8080/api/games -H 'Content-Type: application/json' -d '{"size":6}'
curl -sX POST localhost:8080/api/games/1/ships -H 'Content-Type: application/json' \
     -d '{"shipId":"SH1","size":2,"xA":1,"yA":5,"xB":4,"yB":4}'
curl -sX POST localhost:8080/api/games/1/ships -H 'Content-Type: application/json' \
     -d '{"shipId":"SH2","size":2,"xA":1,"yA":1,"xB":5,"yB":2}'
curl -s      localhost:8080/api/games/1/battlefield
curl -sX POST localhost:8080/api/games/1/start
```

### Errors (`@RestControllerAdvice`, uniform JSON body)
- Rule violation (overlap / out-of-bounds / duplicate id / already started / no ships) → **400**.
- Bean-validation failure on the request body (e.g. odd size, blank shipId) → **400**.
- Unknown game id → **404**.

## Architecture (layers)

```
web        : GameController + DTOs + GlobalExceptionHandler   (HTTP only, no rules)
service    : GameService                                       (4 ops, turn loop, @Transactional)
persistence: GameEntity / ShipEntity / ShotEntity + JpaRepositories   (DB state)
domain     : Board, Ship, Player, Coordinate, PlayerSide       (rules + geometry — no framework)
support    : FireStrategy/RandomFireStrategy, ShipFactory/ShipType, BattleshipException
```

**Why keep a separate pure domain?** All game rules (geometry, overlap, bounds, uniqueness,
fire/destroy) live in framework-free classes. The service **rebuilds the in-memory `Board`/`Ship`
domain from persisted rows** to validate placement and to play the game, then writes results back.
The rules are testable without Spring or a DB, and the same core could sit behind a CLI or gRPC.

### Database model
| Table | Columns (key ones) | Notes |
|---|---|---|
| `game` | id, size, status(`SETUP`/`FINISHED`), winner | one row per game |
| `ship` | id, game_id, owner(A/B), ship_id, size, center_x/y, destroyed | unique `(game_id, owner, ship_id)` |
| `shot` | id, game_id, turn_no, shooter, x, y, outcome(`HIT`/`MISS`), destroyed_ship_id | full replayable history |

`GameEntity` `@OneToMany` ships with cascade + orphan-removal; shots saved in one `saveAll` batch
at the end of `startGame`. Swap H2 → Postgres/MySQL by changing only `application.yml` + the driver.

## Coordinate → cells rule (reconciles both spec examples)
`(x,y)` is the ship's **center vertex**; `half = size/2`, cells span
`[cx-half, cx-half+size-1] × [cy-half, cy-half+size-1]`.
center (2,2) size 4 → (0,0)..(3,3); center (1,5) size 2 → {(0,4),(1,4),(0,5),(1,5)}.

## Patterns (only what the problem needs)
- **Strategy** — `FireStrategy` → `RandomFireStrategy`, injected as a Spring `@Bean`. A new
  targeting algorithm needs zero changes to `GameService`.
- **Factory** — `ShipFactory` + `ShipType` centralize ship creation; new shapes added in one place.
- **Facade / layering** — `GameController` (HTTP) → `GameService` (orchestration) → domain (rules).
- **Repository** — Spring Data `JpaRepository` abstracts persistence from the service.

## SOLID (talking points)
- **SRP** — controller = HTTP, service = flow/transactions, entities = persistence, domain = rules.
- **OCP** — new fire strategy / ship shape / DB vendor without touching existing logic.
- **DIP** — service depends on `FireStrategy` + repository abstractions (constructor-injected);
  a seeded `Random` makes domain tests deterministic.
- **ISP** — `FireStrategy` is a single-method interface; repositories expose only what's used.

## Rules enforced (single `BattleshipException` → 400)
No overlap; ships stay inside their half; unique ids; **no coordinate fired twice**;
one hit destroys a ship; player with 0 ships loses; can't add ships after start / start with none.

## Tests (9)
- `BattleshipApiTest` (5, `@SpringBootTest` + MockMvc + real H2) — full REST game flow ends with a
  persisted winner; overlap→400; unknown game→404; odd size→400; start-without-ships→400.
- `DomainTest` (4) — ship geometry (both spec examples), placement/overlap/bounds/duplicate-id,
  hit-destroys + duplicate-fire rejected, target pool shrinks.

## How I'd extend (mention in the round)
- **Smarter strategies** (Hunt/Target, Parity) via the same `FireStrategy` interface.
- **Non-square ships**: `Ship` → interface + `AbstractShip` (Template Method) + more `ShipType`s.
- **Turn-by-turn REST** (`POST /{id}/fire`) instead of auto-play; persist per-turn state.
- **Prod DB** (Postgres) + Flyway migrations; **Observer** for websocket live updates.

Class diagram: `docs/class-diagram.png` (and `.svg` / `.mmd`).
