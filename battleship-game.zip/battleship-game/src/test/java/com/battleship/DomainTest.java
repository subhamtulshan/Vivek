package com.battleship;

import com.battleship.model.Board;
import com.battleship.model.Coordinate;
import com.battleship.model.PlayerSide;
import com.battleship.model.Ship;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Unit tests for the data layer: Ship geometry and Board rules. */
class DomainTest {

    @Test
    void shipGeometryMatchesSpecExamples() {
        Ship big = new Ship("SH1", 4, new Coordinate(2, 2));
        assertEquals(16, big.getCells().size());
        assertTrue(big.getCells().contains(new Coordinate(0, 0)));
        assertTrue(big.getCells().contains(new Coordinate(3, 3)));

        Ship small = new Ship("SH1", 2, new Coordinate(1, 5));
        assertEquals(4, small.getCells().size());
        assertTrue(small.getCells().contains(new Coordinate(0, 4)));
        assertTrue(small.getCells().contains(new Coordinate(1, 5)));
    }

    @Test
    void placementRejectsOutOfBoundsOverlapAndDuplicateId() {
        Board board = new Board(PlayerSide.PLAYER_A, 0, 2, 0, 5); // PlayerA half of 6x6
        board.placeShip(new Ship("SH1", 2, new Coordinate(1, 5)));

        assertThrows(BattleshipException.class,
                () -> board.placeShip(new Ship("SH2", 2, new Coordinate(4, 4)))); // outside half
        assertThrows(BattleshipException.class,
                () -> board.placeShip(new Ship("SH3", 2, new Coordinate(1, 5)))); // overlap
        assertThrows(BattleshipException.class,
                () -> board.placeShip(new Ship("SH1", 2, new Coordinate(1, 1)))); // duplicate id
    }

    @Test
    void fireHitDestroysShipAndDuplicateFireIsRejected() {
        Board board = new Board(PlayerSide.PLAYER_A, 0, 2, 0, 5);
        board.placeShip(new Ship("SH1", 2, new Coordinate(1, 5)));

        assertNotNull(board.receiveFire(new Coordinate(0, 4)));   // hit
        assertEquals(0, board.aliveShips());
        assertTrue(board.allShipsDestroyed());

        assertNull(board.receiveFire(new Coordinate(2, 0)));       // miss
        assertThrows(BattleshipException.class,
                () -> board.receiveFire(new Coordinate(2, 0)));    // duplicate fire
    }

    @Test
    void remainingTargetsShrinkAfterFire() {
        Board board = new Board(PlayerSide.PLAYER_A, 0, 2, 0, 5);
        assertEquals(18, board.remainingTargets().size());
        board.receiveFire(new Coordinate(0, 0));
        assertEquals(17, board.remainingTargets().size());
        assertFalse(board.remainingTargets().contains(new Coordinate(0, 0)));
    }
}
