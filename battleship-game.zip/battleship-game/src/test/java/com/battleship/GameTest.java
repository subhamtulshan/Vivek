package com.battleship;

import com.battleship.model.Player;
import com.battleship.strategy.RandomFireStrategy;
import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** End-to-end tests driving the public API with a seeded (deterministic) strategy. */
class GameTest {

    private Game newSeededGame(long seed) {
        Game game = new Game(new RandomFireStrategy(new Random(seed)));
        game.initGame(6);
        game.addShip("SH1", 2, 1, 5, 4, 4);
        game.addShip("SH2", 2, 1, 1, 5, 2);
        return game;
    }

    @Test
    void fullGameEndsWithAWinnerAndTheLoserHasNoShips() {
        Game game = newSeededGame(7L);
        game.startGame();

        Player winner = game.getWinner();
        assertNotNull(winner);
        Player loser = (winner == game.getPlayerA()) ? game.getPlayerB() : game.getPlayerA();
        assertEquals(0, loser.aliveShips());
        assertTrue(winner.aliveShips() > 0);
    }

    @Test
    void bothPlayersGetEqualFleet() {
        Game game = newSeededGame(1L);
        assertEquals(game.getPlayerA().getBoard().totalShips(),
                game.getPlayerB().getBoard().totalShips());
        assertEquals(2, game.getPlayerA().getBoard().totalShips());
    }

    @Test
    void apiBeforeInitAndBadConfigAreRejected() {
        Game g = new Game();
        assertThrows(BattleshipException.class, () -> g.addShip("SH1", 2, 1, 5, 4, 4));
        assertThrows(BattleshipException.class, g::startGame);
        assertThrows(BattleshipException.class, () -> g.initGame(5)); // odd N
    }
}
