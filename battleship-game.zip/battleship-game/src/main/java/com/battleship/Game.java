package com.battleship;

import com.battleship.model.Board;
import com.battleship.model.Coordinate;
import com.battleship.model.Player;
import com.battleship.model.PlayerSide;
import com.battleship.model.Ship;
import com.battleship.model.ShipFactory;
import com.battleship.model.ShipType;
import com.battleship.strategy.FireStrategy;
import com.battleship.strategy.RandomFireStrategy;

/**
 * Service layer + facade: exposes the four required APIs and drives the turn loop.
 * Depends on the {@link FireStrategy} abstraction (injected), so a new fire strategy can be
 * swapped in without touching this class. Ships are built via a {@link ShipFactory}.
 */
public class Game {

    private final FireStrategy fireStrategy;
    private final ShipFactory shipFactory;

    private int n;
    private Player playerA;
    private Player playerB;
    private boolean initialized;
    private Player winner;

    public Game() {
        this(new RandomFireStrategy());
    }

    public Game(FireStrategy fireStrategy) {
        this(fireStrategy, new ShipFactory());
    }

    public Game(FireStrategy fireStrategy, ShipFactory shipFactory) {
        this.fireStrategy = fireStrategy;
        this.shipFactory = shipFactory;
    }

    /** Initialize an NxN field: left N/2 columns are PlayerA, right N/2 are PlayerB. */
    public void initGame(int n) {
        if (n <= 0 || n % 2 != 0) {
            throw new BattleshipException("Board size N must be a positive even number, got " + n);
        }
        this.n = n;
        int half = n / 2;
        playerA = new Player(PlayerSide.PLAYER_A, new Board(PlayerSide.PLAYER_A, 0, half - 1, 0, n - 1));
        playerB = new Player(PlayerSide.PLAYER_B, new Board(PlayerSide.PLAYER_B, half, n - 1, 0, n - 1));
        winner = null;
        initialized = true;
    }

    /** Add an equal square ship to both fleets: (xA,yA) for A, (xB,yB) for B. */
    public void addShip(String id, int size, int xA, int yA, int xB, int yB) {
        ensureInitialized();
        Ship shipA = shipFactory.create(ShipType.SQUARE, id, size, new Coordinate(xA, yA));
        Ship shipB = shipFactory.create(ShipType.SQUARE, id, size, new Coordinate(xB, yB));
        playerA.getBoard().placeShip(shipA);
        playerB.getBoard().placeShip(shipB);
    }

    /** Begin the game. PlayerA fires first; players alternate until one loses all ships. */
    public void startGame() {
        ensureInitialized();
        if (playerA.getBoard().totalShips() == 0) {
            throw new BattleshipException("Cannot start: no ships added");
        }

        Player current = playerA;
        Player opponent = playerB;
        while (true) {
            Board oppBoard = opponent.getBoard();
            Coordinate target = fireStrategy.selectTarget(oppBoard);
            Ship destroyed = oppBoard.receiveFire(target);
            printTurn(current, target, destroyed);

            if (opponent.hasLost()) {
                winner = current;
                break;
            }
            Player tmp = current;
            current = opponent;
            opponent = tmp;
        }
        System.out.println("GameOver. " + winner.getName() + " wins.");
    }

    /** Optional: print the field; occupied cells show their ship label (A-SH1 / B-SH2). */
    public void viewBattleField() {
        ensureInitialized();
        int half = n / 2;
        for (int y = n - 1; y >= 0; y--) {
            StringBuilder row = new StringBuilder();
            for (int x = 0; x < n; x++) {
                Board board = (x < half) ? playerA.getBoard() : playerB.getBoard();
                Ship ship = board.shipAt(new Coordinate(x, y));
                String label = (ship == null) ? "." : board.getSide().getPrefix() + "-" + ship.getId();
                row.append(String.format("%-7s", label));
            }
            System.out.println(row.toString().stripTrailing());
        }
    }

    private void printTurn(Player shooter, Coordinate target, Ship destroyed) {
        String result;
        if (destroyed != null) {
            String label = shooter.getSide().opponent().getPrefix() + "-" + destroyed.getId();
            result = "\"Hit\" " + label + " destroyed : ";
        } else {
            result = "\"Miss\" : ";
        }
        System.out.println(shooter.getName() + "'s turn: Missile fired at " + target + " : " + result
                + "Ships Remaining - PlayerA:" + playerA.aliveShips() + ", PlayerB:" + playerB.aliveShips());
    }

    private void ensureInitialized() {
        if (!initialized) {
            throw new BattleshipException("initGame(N) must be called first");
        }
    }

    // Accessors for tests / inspection
    public Player getPlayerA() {
        return playerA;
    }

    public Player getPlayerB() {
        return playerB;
    }

    public Player getWinner() {
        return winner;
    }
}
