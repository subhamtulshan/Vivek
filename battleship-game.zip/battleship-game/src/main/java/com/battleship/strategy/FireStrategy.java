package com.battleship.strategy;

import com.battleship.model.Board;
import com.battleship.model.Coordinate;

/**
 * Strategy Pattern — how a player picks the next cell to fire at. Implementations must
 * return a not-yet-fired cell (from {@link Board#remainingTargets()}), which guarantees the
 * "no coordinate fired twice" rule. New strategies plug in without changing the game (OCP).
 */
public interface FireStrategy {
    Coordinate selectTarget(Board opponentBoard);
}
