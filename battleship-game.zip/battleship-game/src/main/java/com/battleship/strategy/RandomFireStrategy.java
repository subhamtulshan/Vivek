package com.battleship.strategy;

import com.battleship.BattleshipException;
import com.battleship.model.Board;
import com.battleship.model.Coordinate;

import java.util.List;
import java.util.Random;

/**
 * Default "random coordinate fire" strategy. {@link Random} is injected so tests are
 * deterministic (Dependency Inversion).
 */
public class RandomFireStrategy implements FireStrategy {

    private final Random random;

    public RandomFireStrategy() {
        this(new Random());
    }

    public RandomFireStrategy(Random random) {
        this.random = random;
    }

    @Override
    public Coordinate selectTarget(Board opponentBoard) {
        List<Coordinate> targets = opponentBoard.remainingTargets();
        if (targets.isEmpty()) {
            throw new BattleshipException("No unfired coordinates remain on "
                    + opponentBoard.getSide().getDisplayName() + "'s board");
        }
        return targets.get(random.nextInt(targets.size()));
    }
}
