package com.battleship;

/** Demo runner: 6x6 field, two ships per player, reproducing the spec's sample flow. */
public class Main {

    public static void main(String[] args) {
        Game game = new Game();
        try {
            game.initGame(6);
            game.addShip("SH1", 2, 1, 5, 4, 4);   // addShip(id, size, xA, yA, xB, yB)
            game.addShip("SH2", 2, 1, 1, 5, 2);

            System.out.println("Battlefield:");
            game.viewBattleField();
            System.out.println();

            game.startGame();
        } catch (BattleshipException e) {
            System.err.println("Game error: " + e.getMessage());
        }
    }
}
