package com.battleship.model;

import com.battleship.BattleshipException;

import java.util.HashSet;
import java.util.Set;

/**
 * A stationary square ship. The given coordinate is the ship's <em>center vertex</em>;
 * a ship of side {@code size} covers a {@code size x size} block of cells whose lower-left
 * cell is {@code (cx - size/2, cy - size/2)}.
 *
 * <p>Spec examples: center (2,2) size 4 -&gt; cells (0,0)..(3,3);
 * center (1,5) size 2 -&gt; {(0,4),(1,4),(0,5),(1,5)}. A single hit destroys the ship.</p>
 */
public class Ship {

    private final String id;
    private final int size;
    private final Set<Coordinate> cells;
    private boolean destroyed;

    public Ship(String id, int size, Coordinate center) {
        if (id == null || id.isBlank()) throw new BattleshipException("Ship id must not be blank");
        if (size <= 0) throw new BattleshipException("Ship size must be positive, got " + size);
        this.id = id;
        this.size = size;
        this.cells = computeCells(center, size);
    }

    private static Set<Coordinate> computeCells(Coordinate center, int size) {
        int half = size / 2;
        int lowX = center.getX() - half;
        int lowY = center.getY() - half;
        Set<Coordinate> cells = new HashSet<>();
        for (int dx = 0; dx < size; dx++) {
            for (int dy = 0; dy < size; dy++) {
                cells.add(new Coordinate(lowX + dx, lowY + dy));
            }
        }
        return cells;
    }

    public String getId() {
        return id;
    }

    public int getSize() {
        return size;
    }

    public Set<Coordinate> getCells() {
        return cells;
    }

    public boolean isDestroyed() {
        return destroyed;
    }

    public void destroy() {
        this.destroyed = true;
    }
}
