package com.battleship.model;

/** Ship shapes. Add a constant + a branch in {@link ShipFactory} to introduce a new shape. */
public enum ShipType {
    SQUARE
}
