package com.battleship.model;

import com.battleship.BattleshipException;

/**
 * Factory Pattern: centralizes ship creation so the rest of the code never news up a
 * concrete shape. A new ship shape is added here in one place (Open/Closed Principle).
 */
public class ShipFactory {

    public Ship create(ShipType type, String id, int size, Coordinate center) {
        if (type == null) {
            throw new BattleshipException("Ship type must not be null");
        }
        switch (type) {
            case SQUARE:
                return new Ship(id, size, center);
            default:
                throw new BattleshipException("Unsupported ship type: " + type);
        }
    }
}
