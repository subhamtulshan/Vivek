package com.battleship.model;

/** The two players, with display name ("PlayerA") and ship-label prefix ("A"). */
public enum PlayerSide {

    PLAYER_A("PlayerA", "A"),
    PLAYER_B("PlayerB", "B");

    private final String displayName;
    private final String prefix;

    PlayerSide(String displayName, String prefix) {
        this.displayName = displayName;
        this.prefix = prefix;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getPrefix() {
        return prefix;
    }

    public PlayerSide opponent() {
        return this == PLAYER_A ? PLAYER_B : PLAYER_A;
    }
}
