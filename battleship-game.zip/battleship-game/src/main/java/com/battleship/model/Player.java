package com.battleship.model;

/** A player: their side plus the board (half of the field) they defend. */
public class Player {

    private final PlayerSide side;
    private final Board board;

    public Player(PlayerSide side, Board board) {
        this.side = side;
        this.board = board;
    }

    public PlayerSide getSide() {
        return side;
    }

    public String getName() {
        return side.getDisplayName();
    }

    public Board getBoard() {
        return board;
    }

    public int aliveShips() {
        return board.aliveShips();
    }

    public boolean hasLost() {
        return board.allShipsDestroyed();
    }
}
