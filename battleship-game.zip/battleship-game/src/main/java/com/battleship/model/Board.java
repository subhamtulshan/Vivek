package com.battleship.model;

import com.battleship.BattleshipException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Data layer: one player's rectangular half of the field. Owns ship placement, the
 * cell-to-ship index, the set of already-fired cells and the pool of remaining targets.
 * Bounds are inclusive: x in [minX, maxX], y in [minY, maxY].
 */
public class Board {

    private final PlayerSide side;
    private final int minX, maxX, minY, maxY;

    private final Map<String, Ship> fleet = new LinkedHashMap<>();
    private final Map<Coordinate, Ship> cellToShip = new HashMap<>();
    private final Set<Coordinate> fired = new HashSet<>();
    private final List<Coordinate> remainingTargets = new ArrayList<>();
    private int aliveShips;

    public Board(PlayerSide side, int minX, int maxX, int minY, int maxY) {
        this.side = side;
        this.minX = minX;
        this.maxX = maxX;
        this.minY = minY;
        this.maxY = maxY;
        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                remainingTargets.add(new Coordinate(x, y));
            }
        }
    }

    public PlayerSide getSide() {
        return side;
    }

    private boolean inBounds(Coordinate c) {
        return c.getX() >= minX && c.getX() <= maxX && c.getY() >= minY && c.getY() <= maxY;
    }

    /** Places a ship, enforcing: unique id, fully inside this half, no overlap. */
    public void placeShip(Ship ship) {
        if (fleet.containsKey(ship.getId())) {
            throw new BattleshipException("Ship id '" + ship.getId() + "' already exists on " + side.getDisplayName());
        }
        for (Coordinate cell : ship.getCells()) {
            if (!inBounds(cell)) {
                throw new BattleshipException("Ship '" + ship.getId() + "' cell " + cell
                        + " is outside " + side.getDisplayName() + "'s area");
            }
            if (cellToShip.containsKey(cell)) {
                throw new BattleshipException("Ship '" + ship.getId() + "' overlaps ship '"
                        + cellToShip.get(cell).getId() + "' at " + cell);
            }
        }
        fleet.put(ship.getId(), ship);
        ship.getCells().forEach(cell -> cellToShip.put(cell, ship));
        aliveShips++;
    }

    /**
     * Fires at a cell.
     *
     * @return the ship destroyed by this shot, or {@code null} on a miss.
     * @throws BattleshipException if this cell was already fired at.
     */
    public Ship receiveFire(Coordinate target) {
        if (!fired.add(target)) {
            throw new BattleshipException("Coordinate " + target + " has already been fired at");
        }
        remainingTargets.remove(target);
        Ship ship = cellToShip.get(target);
        if (ship != null && !ship.isDestroyed()) {
            ship.destroy();
            aliveShips--;
            return ship;
        }
        return null;
    }

    /** Cells not yet fired at — the pool a fire strategy chooses from. */
    public List<Coordinate> remainingTargets() {
        return Collections.unmodifiableList(remainingTargets);
    }

    public Ship shipAt(Coordinate c) {
        return cellToShip.get(c);
    }

    public int aliveShips() {
        return aliveShips;
    }

    public int totalShips() {
        return fleet.size();
    }

    public boolean allShipsDestroyed() {
        return !fleet.isEmpty() && aliveShips == 0;
    }
}
