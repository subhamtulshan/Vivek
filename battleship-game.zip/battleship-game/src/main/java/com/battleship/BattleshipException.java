package com.battleship;

/** Single exception type for all game-rule violations; handled gracefully by the caller. */
public class BattleshipException extends RuntimeException {
    public BattleshipException(String message) {
        super(message);
    }
}
