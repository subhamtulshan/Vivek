# Battleship Game (Java) — Machine Coding

Lean, interview-ready implementation. Two patterns, clear layering, all four APIs, and tests.

## Run

```bash
mvn test                                                   # 7 tests
mvn compile exec:java -Dexec.mainClass=com.battleship.Main # demo
```

## The 4 APIs (`com.battleship.Game`)

| API | Behaviour |
|---|---|
| `initGame(N)` | N×N field (N positive & even). Left `N/2` cols → PlayerA, right `N/2` → PlayerB. |
| `addShip(id, size, xA, yA, xB, yB)` | Equal square ship for both players. `(x,y)` is the ship's **center vertex**; size-`s` ship covers an `s×s` block of cells. Validates bounds / overlap / duplicate id. |
| `startGame()` | PlayerA fires first; alternate random-coordinate fire until one player loses all ships. |
| `viewBattleField()` | Prints the grid; occupied cells labelled `A-SH1` / `B-SH2`, origin bottom-left. |

**Coordinate → cells rule** (reconciles both spec examples): `half = size/2`, cells span
`[cx-half, cx-half+size-1] × [cy-half, cy-half+size-1]`.
center (2,2) size 4 → cells (0,0)..(3,3); center (1,5) size 2 → {(0,4),(1,4),(0,5),(1,5)}.

## Design

```
service : Game            (4 APIs + turn loop)
data    : Board, Ship, Player, Coordinate, PlayerSide
support : FireStrategy/RandomFireStrategy, ShipFactory/ShipType, BattleshipException
```

### Patterns (only what the problem needs)
- **Strategy** — `FireStrategy` → `RandomFireStrategy`. The spec explicitly asks for pluggable
  fire strategies; `Game` depends on the interface, so a new strategy needs zero changes to `Game`.
- **Factory** — `ShipFactory` + `ShipType` centralize ship creation; new shapes added in one place.

### SOLID (talking points)
- **SRP** — `Board` = state/rules, `Game` = flow, `Ship` = ship data.
- **OCP** — new fire strategy / ship shape without modifying existing classes.
- **DIP** — `Game` depends on `FireStrategy`/`ShipFactory` abstractions, injected via constructor;
  a seeded `Random` makes tests deterministic.
- **Encapsulation** — `Board` hides its maps behind intent methods (`placeShip`, `receiveFire`).

### Rules enforced (single `BattleshipException`)
No overlap; ships stay inside their half; unique ids; **no coordinate fired twice**;
one hit destroys a ship; player with 0 ships loses; guarded uninitialized / empty-fleet use.

## Tests (7)
- `DomainTest` — ship geometry (both spec examples), placement/overlap/bounds/duplicate-id,
  hit destroys ship, duplicate-fire rejected, target pool shrinks.
- `GameTest` — full game via API ends with a winner (loser at 0 ships), equal fleets, bad input rejected.

## How I'd extend (mention in the round, don't build)
- New strategy: implement `FireStrategy`, pass to `new Game(strategy)`.
- New ship shape: subclass/branch in `ShipFactory` + add a `ShipType`.
- Observer for output: introduce a `GameEventListener` and publish instead of `System.out`.

Class diagram: `docs/class-diagram.png` (and `.svg` / `.mmd`).
