# Battleship — Design Doc (interview cheat-sheet)

## 1. Problem in one line
Two players, an N×N sea split in half; each fires random missiles at the opponent's half every
turn (no coordinate twice); one hit destroys a square ship; lose all ships = lose the game.
APIs: `initGame(N)`, `addShip(...)`, `startGame()`, `viewBattleField()`.

## 2. Key modelling decisions (say these out loud)
- **Coordinate = a cell** `(x=col, y=row)`, zero-based, immutable value object (equals/hashCode →
  usable as a map/set key).
- **Ship position `(x,y)` = the ship's *center vertex*.** A size-`s` square covers an `s×s` block
  of cells whose lower-left cell is `(x - s/2, y - s/2)`.
  - Reconciles both spec examples: center (2,2) size 4 → cells (0,0)..(3,3); center (1,5) size 2 →
    {(0,4),(1,4),(0,5),(1,5)}. This was the trickiest ambiguity — call it out.
- **Board split:** left `N/2` columns `x∈[0,N/2-1]` = PlayerA, right `x∈[N/2,N-1]` = PlayerB.
  N must be positive & even.
- **One hit destroys the whole ship** (spec), so I don't track per-cell damage — just a
  `cellToShip` index + a `destroyed` flag.
- **"No coordinate fired twice"** → each Board keeps a `remainingTargets` pool; the strategy only
  ever picks from it, so uniqueness is structural, not a re-roll loop.

## 3. Class responsibilities (SRP)
| Class | Layer | Responsibility |
|---|---|---|
| `Coordinate` | data | immutable cell (x,y) |
| `PlayerSide` (enum) | data | A/B + display name + label prefix + `opponent()` |
| `Ship` | data | id, size, computed occupied cells, destroyed flag |
| `Board` | data | one half: place ships (validate), receive fire, target pool, alive count |
| `Player` | data | a side + its board |
| `FireStrategy` / `RandomFireStrategy` | support | how to pick the next target (Strategy) |
| `ShipFactory` / `ShipType` | support | create ships (Factory) |
| `BattleshipException` | support | one type for all rule violations |
| `Game` | service/facade | the 4 APIs + turn loop + output |

Clean **data ↔ service** split: `Board/Ship/Player` hold state and enforce local rules; `Game`
orchestrates flow. No I/O in the data layer.

## 4. Patterns (only what's needed)
- **Strategy — `FireStrategy`.** Spec explicitly wants pluggable fire strategies. `Game` depends on
  the interface, so a new strategy (hunt/target, parity) drops in with **zero** changes to `Game`.
- **Factory — `ShipFactory` + `ShipType`.** Centralizes construction; a new ship shape is added in
  one place. Rest of the code depends only on `Ship`.
- **Facade — `Game`.** Hides wiring behind the 4 required methods.

## 5. SOLID mapping
- **S** — each class one job (table above).
- **O** — new strategy / ship shape without editing existing classes.
- **L** — any `FireStrategy` substitutes the interface.
- **I** — `FireStrategy` is a single-method interface; no fat contracts.
- **D** — `Game` depends on abstractions (`FireStrategy`, `ShipFactory`) injected via constructor;
  a **seeded `Random`** makes tests deterministic.

## 6. Game flow (`startGame`)
```
current=A, opponent=B
loop:
  target = fireStrategy.selectTarget(opponent.board)   // from remainingTargets
  destroyed = opponent.board.receiveFire(target)        // marks fired, returns ship or null
  print turn (Hit/Miss, ships remaining)
  if opponent.allShipsDestroyed(): winner=current; break
  swap(current, opponent)
print "GameOver. <winner> wins."
```

## 7. Rules & edge cases handled
- Ship fully inside its half; **no overlap**; touching allowed; unique id per fleet.
- Firing an already-fired cell → exception (never happens via strategy, but Board guards it).
- Use before `initGame`, odd/negative N, `startGame` with no ships → clear exceptions.
- Termination guaranteed: every hit destroys a ship and cells are finite, so a player runs out.

## 8. Complexity
- `addShip`: O(s²) cells. `receiveFire`: O(1) hit lookup (map) + O(T) remove from target list.
- Memory: O(N²) for the target pools + O(total ship cells).
- (Optimization option: swap the target `List` for index-based swap-remove to make removal O(1).)

## 9. Tests (7)
- `DomainTest` — ship geometry (both examples), placement/overlap/bounds/duplicate-id,
  hit-destroys, duplicate-fire rejected, target pool shrinks.
- `GameTest` — full game via API: winner decided (loser at 0 ships), equal fleets, bad input rejected.
- Determinism via seeded `Random`.

---

## 10. What else could be done (extensions — mention, don't build)
**Gameplay / rules**
- **Smarter strategies** via the same `FireStrategy` interface: *Hunt/Target* (after a hit, probe
  neighbours), *Parity/Checkerboard*, *Probability-density* targeting.
- **Non-square ships** (rectangle/line): make `Ship` an interface + `AbstractShip` (Template Method),
  add subclasses, extend `ShipType` — no change to `Board`/`Game`.
- **Partial damage**: track hit cells per ship; "destroyed only when all cells hit" (change one method).
- **Human player / mixed players**: extract a `Player` strategy (input source) so human vs bot works.

**Architecture / quality**
- **Observer pattern** for output: `GameEventListener` + publisher → swap console for GUI/file/replay
  log/test collector without touching `Game`.
- **Builder** for game setup (fluent `addShip` chaining, config object).
- **Immutability / thread-safety** if turns run concurrently.
- **Persistence**: save/restore game state (Memento) for pause/resume.
- **Configurable board split / fleet templates** loaded from JSON.

**Robustness / product**
- Richer validation messages, input parsing layer (CLI/REST) separate from core.
- Metrics/logging (shots fired, hit rate), seedable games for reproducible bug reports.
- More tests: property-based (no overlap ever), full-board exhaustion, large-N performance.
