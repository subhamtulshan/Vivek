"""Streamlit demo: streamlit run app.py --server.port 8000

Uses the real LLM raters when OPENAI_API_KEY is set, otherwise a deterministic
offline demo panel so the UI works without network access.
"""
import json
import os
import random
from dataclasses import asdict
from pathlib import Path

import streamlit as st

from src.consensus_workflow import ConsensusWorkflow
from src.models import AgentRegistry, ConsensusConfig, RaterUnavailableError, RaterVerdict, SegmentRef

DIMS = ["accuracy", "terminology", "fluency", "localization_policy", "formatting"]


class DemoRater:
    def __init__(self, dimension, flaky):
        self.dimension, self.flaky = dimension, flaky

    def review(self, segment):
        rng = random.Random(f"{segment.segment_id}:{self.dimension}")
        if self.flaky and rng.random() < 0.4:
            raise RaterUnavailableError("demo timeout")
        hard = self.dimension == "formatting" and "{" in segment.source_text \
            and "{" not in segment.translation_text
        return RaterVerdict(f"{self.dimension}_demo", self.dimension,
                            "reject" if hard else "approve", round(rng.uniform(0.5, 1.0), 2), hard)


def build_registry(flaky):
    if os.environ.get("OPENAI_API_KEY"):
        from src.agents import (AccuracyRater, FluencyRater, FormattingRater,
                                LocalizationPolicyRater, TerminologyRater)
        from src.llm import LLMClient
        llm = LLMClient()
        return AgentRegistry(AccuracyRater(llm), TerminologyRater(llm), FluencyRater(llm),
                             LocalizationPolicyRater(llm), FormattingRater(llm))
    return AgentRegistry(*[DemoRater(d, flaky) for d in DIMS])


st.title("Translation Quality Consensus")
samples = json.loads(Path("data/sample_segments.json").read_text(encoding="utf-8"))
pick = st.selectbox("Sample", range(len(samples)), format_func=lambda i: samples[i]["segment_id"] or "(blank id)")
seg = samples[pick]
c1, c2 = st.columns(2)
segment = SegmentRef(
    segment_id=c1.text_input("segment_id", seg["segment_id"]),
    source_text=c1.text_area("source_text", seg["source_text"]),
    translation_text=c2.text_area("translation_text", seg["translation_text"]),
    locale=c2.text_input("locale", seg["locale"]),
    context=c2.text_input("context", seg["context"]),
)
with st.sidebar:
    cfg = ConsensusConfig(
        approve_quorum=st.number_input("approve_quorum", 1, 5, 3),
        reject_quorum=st.number_input("reject_quorum", 1, 5, 3),
        min_confidence=st.slider("min_confidence", 0.0, 1.0, 0.6),
        max_retries=st.number_input("max_retries", 0, 5, 1),
    )
    flaky = st.checkbox("Simulate flaky raters (demo mode)")

if st.button("Review"):
    decision = ConsensusWorkflow(build_registry(flaky), cfg).review(segment)
    st.subheader(f"{decision.status.upper()} · {decision.reason or decision.error}")
    st.json(asdict(decision))
