import pytest

from src.models import AgentRegistry, ConsensusConfig, RaterVerdict, SegmentRef

DIMENSIONS = ["accuracy", "terminology", "fluency", "localization_policy", "formatting"]


def ok(verdict="approve", confidence=0.9, hard_issue=False, dimension="x"):
    return RaterVerdict(rater_id=f"{dimension}_rater", dimension=dimension,
                        verdict=verdict, confidence=confidence, hard_issue=hard_issue)


class FakeRater:
    """Plays back a script, one item per call (the last item repeats).

    An item can be a RaterVerdict / dict / None (returned as-is) or an
    Exception instance (raised).
    """

    def __init__(self, dimension, *script):
        self.dimension = dimension
        self.rater_id = f"{dimension}_rater"
        self.script = list(script) or [ok(dimension=dimension)]
        self.calls = 0
        self.seen = []

    def review(self, segment):
        self.seen.append(segment)
        item = self.script[min(self.calls, len(self.script) - 1)]
        self.calls += 1
        if isinstance(item, BaseException):
            raise item
        return item


def make_registry(*scripts):
    """make_registry([...accuracy script], [...terminology script], ...) -> (registry, raters)."""
    raters = [FakeRater(dim, *script) for dim, script in zip(DIMENSIONS, scripts)]
    kwargs = dict(zip(DIMENSIONS, raters))
    return AgentRegistry(**kwargs), raters


@pytest.fixture
def segment():
    return SegmentRef(
        segment_id="SEG-1001",
        source_text="Save changes",
        translation_text="Guardar cambios",
        locale="es-ES",
        context="Software UI button label",
    )


@pytest.fixture
def config():
    return ConsensusConfig()  # panel 5, quorum 3/3, min_confidence 0.6, max_retries 1
