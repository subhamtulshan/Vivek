"""Corner-case tests for ConsensusWorkflow.review().

Grouped by rule: validation, retries, confidence, hard issues, quorum,
escalation, robustness, scale.
"""
import math
from dataclasses import asdict

import pytest

from src.consensus_workflow import ConsensusWorkflow
from src.models import (AgentRegistry, ConsensusConfig, RaterUnavailableError,
                        SegmentRef, TraceEvent)
from tests.conftest import FakeRater, make_registry, ok

UNAVAILABLE = RaterUnavailableError("timeout")          # transient=True by default
DOWN_FOR_GOOD = RaterUnavailableError("gone", transient=False)

APPROVE = [ok("approve", 0.9)]
REJECT = [ok("reject", 0.9)]


def run(scripts, segment, config=None):
    registry, raters = make_registry(*scripts)
    decision = ConsensusWorkflow(registry, config or ConsensusConfig()).review(segment)
    return decision, raters


def steps(decision):
    return [(e.step, e.attempt, e.status) for e in decision.trace]


# --------------------------------------------------------------------------- 1. validation
@pytest.mark.parametrize("bad", [
    None,
    SegmentRef(segment_id="", source_text="a", translation_text="b"),
    SegmentRef(segment_id="   ", source_text="a", translation_text="b"),
    SegmentRef(segment_id=None, source_text="a", translation_text="b"),
    SegmentRef(segment_id=1001, source_text="a", translation_text="b"),     # non-string id
    SegmentRef(segment_id="S1", source_text="", translation_text="b"),
    SegmentRef(segment_id="S1", source_text="a", translation_text=""),
    SegmentRef(segment_id="S1", source_text="a", translation_text=" \n\t "),
    SegmentRef(segment_id="S1", source_text=None, translation_text="b"),
    SegmentRef(segment_id="S1", source_text="a", translation_text=123),
    {"segment_id": "S1", "source_text": "a"},                                # dict, missing key
    {},
    "not a segment",
])
def test_invalid_request_never_calls_raters(bad):
    registry, raters = make_registry(*[APPROVE] * 5)
    d = ConsensusWorkflow(registry, ConsensusConfig()).review(bad)
    assert d.status == "error"
    assert d.error == "INVALID_REQUEST"
    assert d.vote_summary is None
    assert d.reason is None
    assert d.trace == []
    assert all(r.calls == 0 for r in raters)


def test_invalid_request_echoes_string_id_or_none():
    wf = ConsensusWorkflow(make_registry(APPROVE)[0], ConsensusConfig())
    assert wf.review(SegmentRef("S9", "a", "")).segment_id == "S9"
    assert wf.review(None).segment_id is None


def test_dict_input_is_accepted(segment):
    registry, raters = make_registry(*[APPROVE] * 5)
    d = ConsensusWorkflow(registry, ConsensusConfig()).review(asdict(segment))
    assert d.status == "approved"
    assert isinstance(raters[0].seen[0], SegmentRef)


def test_optional_fields_may_be_empty():
    d, _ = run([APPROVE] * 5, SegmentRef("S1", "Hi", "Hola"))   # no locale / context
    assert d.status == "approved"


# --------------------------------------------------------------------------- 2. retries + trace
def test_transient_failure_then_success_is_retried(segment):
    d, raters = run([[UNAVAILABLE, ok()], APPROVE, APPROVE, APPROVE, APPROVE], segment)
    assert d.status == "approved"
    assert raters[0].calls == 2
    assert steps(d)[:2] == [("accuracy", 1, "unavailable"), ("accuracy", 2, "success")]
    assert len(d.trace) == 6                       # one entry per attempt
    assert d.vote_summary.abstained_unavailable == 0


def test_retries_exhausted_counts_as_abstained(segment):
    cfg = ConsensusConfig(max_retries=2)
    d, raters = run([[UNAVAILABLE]] + [APPROVE] * 4, segment, cfg)
    assert raters[0].calls == 3                    # 1 try + 2 retries
    assert steps(d)[:3] == [("accuracy", n, "unavailable") for n in (1, 2, 3)]
    assert d.vote_summary.abstained_unavailable == 1
    assert d.status == "approved"                  # 4 approvals still reach quorum 3


def test_max_retries_zero_means_single_attempt(segment):
    d, raters = run([[UNAVAILABLE, ok()]] + [APPROVE] * 4, segment, ConsensusConfig(max_retries=0))
    assert raters[0].calls == 1
    assert d.vote_summary.abstained_unavailable == 1


def test_negative_max_retries_treated_as_zero(segment):
    d, raters = run([[UNAVAILABLE]] + [APPROVE] * 4, segment, ConsensusConfig(max_retries=-5))
    assert raters[0].calls == 1


def test_non_transient_unavailable_is_not_retried(segment):
    d, raters = run([[DOWN_FOR_GOOD, ok()]] + [APPROVE] * 4, segment, ConsensusConfig(max_retries=5))
    assert raters[0].calls == 1
    assert steps(d)[0] == ("accuracy", 1, "unavailable")


def test_unexpected_exception_is_not_retried_and_does_not_crash(segment):
    d, raters = run([[ValueError("bad json"), ok()]] + [APPROVE] * 4, segment)
    assert raters[0].calls == 1
    assert steps(d)[0] == ("accuracy", 1, "error")
    assert d.vote_summary.abstained_unavailable == 1
    assert d.status == "approved"


def test_trace_events_are_trace_event_objects_in_panel_order(segment):
    d, _ = run([APPROVE] * 5, segment)
    assert all(isinstance(e, TraceEvent) for e in d.trace)
    assert [e.step for e in d.trace] == [
        "accuracy", "terminology", "fluency", "localization_policy", "formatting"]


# --------------------------------------------------------------------------- 3. missing / malformed responses
@pytest.mark.parametrize("bad_reply", [
    None,
    ok(verdict="maybe"),
    ok(verdict=None),
    ok(confidence=None),
    ok(confidence=float("nan")),
    ok(confidence=-0.1),
    ok(confidence=1.01),
    ok(confidence=True),          # bool is an int in Python; reject it
    ok(confidence="0.9"),
    {"unexpected": "shape"},
])
def test_missing_or_malformed_reply_counts_as_abstained(segment, bad_reply):
    d, raters = run([[bad_reply]] + [APPROVE] * 4, segment)
    assert raters[0].calls == 1                    # not retried
    assert steps(d)[0] == ("accuracy", 1, "missing")
    assert d.vote_summary.abstained_unavailable == 1
    assert d.vote_summary.approvals == 4


def test_verdict_is_case_and_space_insensitive(segment):
    d, _ = run([[ok(" APPROVE ")], [ok("Approved")], APPROVE, APPROVE, APPROVE], segment)
    assert d.vote_summary.approvals == 5


def test_dict_reply_is_accepted(segment):
    d, _ = run([[{"verdict": "approve", "confidence": 0.9}]] + [APPROVE] * 4, segment)
    assert d.vote_summary.approvals == 5


# --------------------------------------------------------------------------- 4. min_confidence
def test_confidence_equal_to_threshold_counts(segment):
    d, _ = run([[ok(confidence=0.6)]] * 3 + [[ok(confidence=0.1)]] * 2, segment)
    assert d.vote_summary.approvals == 3
    assert d.status == "approved"


def test_confidence_just_below_threshold_is_ignored(segment):
    d, _ = run([[ok(confidence=0.5999999)]] * 5, segment)
    assert d.vote_summary.approvals == 0
    assert d.status == "escalated"
    assert d.reason == "NO_QUORUM"                 # they answered, just not confidently
    assert d.vote_summary.abstained_unavailable == 0


def test_min_confidence_zero_counts_everything(segment):
    d, _ = run([[ok(confidence=0.0)]] * 5, segment, ConsensusConfig(min_confidence=0.0))
    assert d.vote_summary.approvals == 5


def test_min_confidence_one_requires_certainty(segment):
    cfg = ConsensusConfig(min_confidence=1.0)
    d, _ = run([[ok(confidence=1.0)]] * 3 + [[ok(confidence=0.99)]] * 2, segment, cfg)
    assert d.vote_summary.approvals == 3


def test_integer_confidence_is_valid(segment):
    d, _ = run([[ok(confidence=1)]] * 5, segment)
    assert d.vote_summary.approvals == 5


# --------------------------------------------------------------------------- 5. hard issues
@pytest.mark.parametrize("position", range(5))
def test_hard_issue_blocks_and_short_circuits(segment, position):
    scripts = [APPROVE] * 5
    scripts[position] = [ok("reject", 0.9, hard_issue=True)]
    d, raters = run(scripts, segment)
    assert d.status == "blocked"
    assert d.reason == "HARD_ISSUE"
    assert d.error is None
    assert d.vote_summary.hard_issues == 1
    assert len(d.trace) == position + 1            # only attempts that actually ran
    assert all(r.calls == 0 for r in raters[position + 1:])


def test_hard_issue_beats_an_already_reached_quorum(segment):
    d, _ = run([APPROVE, APPROVE, APPROVE, APPROVE, [ok(hard_issue=True)]], segment)
    assert d.status == "blocked"
    assert d.vote_summary.approvals == 4


def test_hard_issue_blocks_even_with_low_confidence(segment):
    d, _ = run([[ok("approve", 0.01, hard_issue=True)]] + [APPROVE] * 4, segment)
    assert d.status == "blocked"


def test_hard_issue_after_a_retry(segment):
    d, _ = run([[UNAVAILABLE, ok(hard_issue=True)]] + [APPROVE] * 4, segment)
    assert d.status == "blocked"
    assert steps(d) == [("accuracy", 1, "unavailable"), ("accuracy", 2, "success")]


def test_hard_issue_string_false_is_not_a_hard_issue(segment):
    reply = {"verdict": "approve", "confidence": 0.9, "hard_issue": "false"}
    d, _ = run([[reply]] + [APPROVE] * 4, segment)
    assert d.status == "approved"


# --------------------------------------------------------------------------- 6. quorum
def test_reject_quorum(segment):
    d, _ = run([REJECT, REJECT, REJECT, APPROVE, APPROVE], segment)
    assert (d.status, d.reason) == ("rejected", "QUORUM_REJECT")
    assert (d.vote_summary.approvals, d.vote_summary.rejections) == (2, 3)


def test_exactly_quorum_approves(segment):
    d, _ = run([APPROVE, APPROVE, APPROVE, REJECT, REJECT], segment)
    assert d.status == "approved"


def test_both_quorums_reached_is_a_split(segment):
    cfg = ConsensusConfig(approve_quorum=2, reject_quorum=2)
    d, _ = run([APPROVE, APPROVE, REJECT, REJECT, [ok(confidence=0.1)]], segment, cfg)
    assert (d.status, d.reason) == ("escalated", "NO_QUORUM")


def test_asymmetric_quorums(segment):
    cfg = ConsensusConfig(approve_quorum=5, reject_quorum=1)  # strict approve, any reject wins
    d, _ = run([APPROVE, APPROVE, APPROVE, APPROVE, REJECT], segment, cfg)
    assert d.status == "rejected"


def test_zero_quorum_never_approves_without_votes(segment):
    cfg = ConsensusConfig(approve_quorum=0, reject_quorum=0)
    d, _ = run([[UNAVAILABLE]] * 5, segment, cfg)
    assert d.status == "escalated"                 # quorum is clamped to >= 1


def test_quorum_larger_than_panel_escalates(segment):
    d, _ = run([APPROVE] * 5, segment, ConsensusConfig(approve_quorum=6))
    assert d.status == "escalated"


# --------------------------------------------------------------------------- 7. escalation
def test_split_without_winner(segment):
    d, _ = run([APPROVE, APPROVE, REJECT, REJECT, [ok(confidence=0.2)]], segment)
    assert (d.status, d.reason) == ("escalated", "NO_QUORUM")


def test_too_many_failures_is_insufficient_raters(segment):
    d, _ = run([[UNAVAILABLE]] * 3 + [APPROVE, APPROVE], segment)
    assert (d.status, d.reason) == ("escalated", "INSUFFICIENT_RATERS")
    assert d.vote_summary.abstained_unavailable == 3
    assert len(d.trace) == 3 * 2 + 2               # 3 raters x 2 attempts + 2 single attempts


def test_all_raters_down(segment):
    d, _ = run([[UNAVAILABLE]] * 5, segment)
    assert (d.status, d.reason) == ("escalated", "INSUFFICIENT_RATERS")
    assert d.vote_summary.abstained_unavailable == 5
    assert len(d.trace) == 10


def test_two_failures_but_quorum_still_reached(segment):
    d, _ = run([[UNAVAILABLE], [None], APPROVE, APPROVE, APPROVE], segment)
    assert d.status == "approved"


def test_two_failures_and_split_is_no_quorum(segment):
    d, _ = run([[UNAVAILABLE], [None], APPROVE, APPROVE, REJECT], segment)
    assert (d.status, d.reason) == ("escalated", "NO_QUORUM")


def test_empty_registry(segment):
    d = ConsensusWorkflow(AgentRegistry(), ConsensusConfig()).review(segment)
    assert (d.status, d.reason) == ("escalated", "INSUFFICIENT_RATERS")
    assert d.trace == []


def test_partial_registry_skips_missing_slots(segment):
    registry = AgentRegistry(accuracy=FakeRater("accuracy"), formatting=FakeRater("formatting"),
                             fluency=FakeRater("fluency"))
    d = ConsensusWorkflow(registry, ConsensusConfig()).review(segment)
    assert [e.step for e in d.trace] == ["accuracy", "fluency", "formatting"]
    assert d.status == "approved"


# --------------------------------------------------------------------------- 8. robustness
def test_no_state_leaks_between_reviews(segment):
    registry, _ = make_registry(*[APPROVE] * 5)
    wf = ConsensusWorkflow(registry, ConsensusConfig())
    first, second = wf.review(segment), wf.review(segment)
    assert first.trace is not second.trace
    assert first.vote_summary is not second.vote_summary
    assert len(second.trace) == 5 and second.vote_summary.approvals == 5


def test_input_segment_is_not_mutated(segment):
    before = asdict(segment)
    run([APPROVE] * 5, segment)
    assert asdict(segment) == before


def test_broken_registry_returns_error_instead_of_raising(segment):
    class Broken:
        def panel(self):
            raise RuntimeError("registry down")
    d = ConsensusWorkflow(Broken(), ConsensusConfig()).review(segment)
    assert d.status == "error"
    assert "INTERNAL_ERROR" in d.error


def test_none_config_uses_defaults(segment):
    registry, _ = make_registry(*[APPROVE] * 5)
    assert ConsensusWorkflow(registry, None).review(segment).status == "approved"


def test_keyboard_interrupt_is_not_swallowed(segment):
    with pytest.raises(KeyboardInterrupt):
        run([[KeyboardInterrupt()]] + [APPROVE] * 4, segment)


# --------------------------------------------------------------------------- 9. scale: large / small values
def test_huge_text_and_unicode(segment):
    big = SegmentRef("SEG-BIG", "Ä😀" * 500_000, "ß漢字" * 500_000, "ja-JP", "x" * 10_000)
    d, raters = run([APPROVE] * 5, big)
    assert d.status == "approved"
    assert raters[0].seen[0] is big                # passed through, not copied


def test_large_retry_budget_stops_at_first_success(segment):
    cfg = ConsensusConfig(max_retries=10_000)
    script = [UNAVAILABLE] * 999 + [ok()]
    d, raters = run([script] + [APPROVE] * 4, segment, cfg)
    assert raters[0].calls == 1000
    assert len(d.trace) == 1000 + 4


def test_large_custom_panel(segment):
    class Registry:
        def panel(self):
            return [FakeRater(f"r{i}") for i in range(2000)]
    d = ConsensusWorkflow(Registry(), ConsensusConfig(approve_quorum=1500)).review(segment)
    assert d.status == "approved"
    assert d.vote_summary.approvals == 2000


def test_tiny_float_threshold(segment):
    cfg = ConsensusConfig(min_confidence=1e-12)
    d, _ = run([[ok(confidence=1e-12)]] * 5, segment, cfg)
    assert d.vote_summary.approvals == 5


def test_nan_min_confidence_falls_back_to_default(segment):
    d, _ = run([[ok(confidence=0.7)]] * 5, segment, ConsensusConfig(min_confidence=math.nan))
    assert d.status == "approved"
