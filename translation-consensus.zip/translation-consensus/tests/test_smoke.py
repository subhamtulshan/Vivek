from dataclasses import asdict

from src.consensus_workflow import ConsensusWorkflow
from tests.conftest import make_registry, ok


def test_example_from_spec(segment, config):
    registry, _ = make_registry(*[[ok()] for _ in range(5)])
    result = asdict(ConsensusWorkflow(registry, config).review(segment))
    assert result == {
        "segment_id": "SEG-1001",
        "status": "approved",
        "vote_summary": {"approvals": 5, "rejections": 0,
                         "abstained_unavailable": 0, "hard_issues": 0},
        "reason": "QUORUM_APPROVE",
        "error": None,
        "trace": [
            {"step": "accuracy", "attempt": 1, "status": "success"},
            {"step": "terminology", "attempt": 1, "status": "success"},
            {"step": "fluency", "attempt": 1, "status": "success"},
            {"step": "localization_policy", "attempt": 1, "status": "success"},
            {"step": "formatting", "attempt": 1, "status": "success"},
        ],
    }
