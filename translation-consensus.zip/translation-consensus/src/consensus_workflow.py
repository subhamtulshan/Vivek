"""Translation Quality Consensus Workflow.

Runs the specialist rater panel over ONE translated segment and folds the
raters' separate verdicts into a single ConsensusDecision.

Decision pipeline (order matters):

    1. Validate the request          -> status "error",  error  INVALID_REQUEST
    2. Ask raters one by one (panel order), retrying transient unavailability
         - any hard issue            -> status "blocked", reason HARD_ISSUE  (stop at once)
    3. Tally votes that meet min_confidence
         - approvals reach quorum    -> status "approved", reason QUORUM_APPROVE
         - rejections reach quorum   -> status "rejected", reason QUORUM_REJECT
         - too few raters responded  -> status "escalated", reason INSUFFICIENT_RATERS
         - otherwise (split)         -> status "escalated", reason NO_QUORUM
"""
import math
import re
from collections.abc import Mapping

from src.models import (
    AgentRegistry,
    ConsensusConfig,
    ConsensusDecision,
    ErrorCode,
    RaterUnavailableError,
    Reason,
    SegmentRef,
    TraceEvent,
    VoteSummary,
)

# ---- output vocabulary ------------------------------------------------------
STATUS_APPROVED = "approved"
STATUS_REJECTED = "rejected"
STATUS_BLOCKED = "blocked"
STATUS_ESCALATED = "escalated"
STATUS_ERROR = "error"

TRACE_SUCCESS = "success"          # rater answered with a usable verdict
TRACE_UNAVAILABLE = "unavailable"  # rater raised RaterUnavailableError
TRACE_ERROR = "error"              # rater crashed with any other exception
TRACE_MISSING = "missing"          # rater returned nothing / a malformed verdict

INTERNAL_ERROR = "INTERNAL_ERROR"

_APPROVE_WORDS = {"approve", "approved"}
_REJECT_WORDS = {"reject", "rejected"}
_RATER_METHODS = ("review", "rate", "evaluate", "run")  # first one found is used


class ConsensusWorkflow:

    def __init__(self, raters: AgentRegistry, config: ConsensusConfig):
        self._raters = raters
        self._config = config if config is not None else ConsensusConfig()

    # ------------------------------------------------------------------ public
    def review(self, segment: SegmentRef) -> ConsensusDecision:
        # 1. Validate up front. Invalid requests never reach a rater.
        segment, segment_id = _coerce_segment(segment)
        if segment is None:
            return ConsensusDecision(
                segment_id=segment_id,
                status=STATUS_ERROR,
                vote_summary=None,
                reason=None,
                error=ErrorCode.INVALID_REQUEST.value,
                trace=[],
            )

        trace = []
        summary = VoteSummary()
        try:
            return self._run_panel(segment, summary, trace)
        except Exception as exc:  # pylint: disable=broad-except
            # Safety net: a bug or a broken registry must not crash the caller.
            # Report what actually ran so far.
            return ConsensusDecision(
                segment_id=segment.segment_id,
                status=STATUS_ERROR,
                vote_summary=summary,
                reason=None,
                error=f"{INTERNAL_ERROR}: {type(exc).__name__}: {exc}",
                trace=trace,
            )

    # ----------------------------------------------------------------- private
    def _run_panel(self, segment, summary, trace):
        min_conf = self._min_confidence()
        responded = 0  # raters that produced a usable verdict (any confidence)

        for rater in self._panel():
            step = _step_name(rater)
            parsed = self._ask_with_retries(rater, step, segment, trace)

            if parsed is None:  # unavailable after retries, crashed, or no answer
                summary.abstained_unavailable += 1
                continue

            verdict, confidence, hard_issue = parsed
            responded += 1

            # 2. Hard issue: block now and skip the remaining raters.
            #    Ignores confidence on purpose (fail safe, e.g. medical text).
            if hard_issue:
                summary.hard_issues += 1
                return self._decision(segment, STATUS_BLOCKED, Reason.HARD_ISSUE, summary, trace)

            # 3. Count the vote only if it meets min_confidence (>= is inclusive).
            if confidence < min_conf:
                continue
            if verdict == "approve":
                summary.approvals += 1
            else:
                summary.rejections += 1

        approve_q = self._quorum("approve_quorum")
        reject_q = self._quorum("reject_quorum")
        approve_hit = summary.approvals >= approve_q
        reject_hit = summary.rejections >= reject_q

        if approve_hit and not reject_hit:
            return self._decision(segment, STATUS_APPROVED, Reason.QUORUM_APPROVE, summary, trace)
        if reject_hit and not approve_hit:
            return self._decision(segment, STATUS_REJECTED, Reason.QUORUM_REJECT, summary, trace)
        # No single winner. If so few raters answered that neither quorum
        # was reachable, the cause is missing raters, not disagreement.
        if responded < min(approve_q, reject_q):
            return self._decision(segment, STATUS_ESCALATED, Reason.INSUFFICIENT_RATERS, summary, trace)
        return self._decision(segment, STATUS_ESCALATED, Reason.NO_QUORUM, summary, trace)

    def _ask_with_retries(self, rater, step, segment, trace):
        """Call one rater. Return (verdict, confidence, hard_issue) or None.

        Adds exactly one TraceEvent per attempt. Only a *transient*
        RaterUnavailableError is retried, up to max_retries extra attempts.
        """
        max_attempts = 1 + self._max_retries()
        for attempt in range(1, max_attempts + 1):
            try:
                raw = _call_rater(rater, segment)
            except RaterUnavailableError as exc:
                trace.append(TraceEvent(step=step, attempt=attempt, status=TRACE_UNAVAILABLE))
                if getattr(exc, "transient", True) is False:
                    return None  # permanent outage: retrying cannot help
                continue
            except Exception:  # pylint: disable=broad-except
                # A bug or a bad payload in one rater. Don't retry, don't crash the panel.
                trace.append(TraceEvent(step=step, attempt=attempt, status=TRACE_ERROR))
                return None

            parsed = _parse_verdict(raw)
            if parsed is None:
                trace.append(TraceEvent(step=step, attempt=attempt, status=TRACE_MISSING))
                return None
            trace.append(TraceEvent(step=step, attempt=attempt, status=TRACE_SUCCESS))
            return parsed
        return None  # every attempt was unavailable

    def _decision(self, segment, status, reason, summary, trace):
        return ConsensusDecision(
            segment_id=segment.segment_id,
            status=status,
            vote_summary=summary,
            reason=reason.value,
            error=None,
            trace=trace,
        )

    # ---- defensive config / registry access ---------------------------------
    def _panel(self):
        raters = self._raters
        if raters is None:
            return []
        panel = raters.panel() if hasattr(raters, "panel") else list(raters)
        return [r for r in panel if r is not None]

    def _max_retries(self):
        value = getattr(self._config, "max_retries", 1)
        if isinstance(value, bool) or not isinstance(value, int):
            return 1
        return max(0, value)  # a negative value means "no retries"

    def _quorum(self, name):
        value = getattr(self._config, name, 3)
        if isinstance(value, bool) or not isinstance(value, int):
            return 3
        return max(1, value)  # quorum 0 would approve with zero votes

    def _min_confidence(self):
        value = getattr(self._config, "min_confidence", 0.6)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or math.isnan(value):
            return 0.6
        return float(value)


# ---- module helpers ---------------------------------------------------------
def _is_text(value):
    return isinstance(value, str) and value.strip() != ""


def _coerce_segment(segment):
    """Return (SegmentRef or None if invalid, segment_id to echo back)."""
    if segment is None:
        return None, None
    if isinstance(segment, Mapping):  # the app or callers may pass a plain dict
        get = segment.get
    else:
        def get(key, default=None):
            return getattr(segment, key, default)

    segment_id = get("segment_id")
    echo_id = segment_id if isinstance(segment_id, str) else None
    if not (_is_text(segment_id) and _is_text(get("source_text")) and _is_text(get("translation_text"))):
        return None, echo_id

    if isinstance(segment, SegmentRef):
        return segment, segment_id
    locale, context = get("locale", ""), get("context", "")
    return SegmentRef(
        segment_id=segment_id,
        source_text=get("source_text"),
        translation_text=get("translation_text"),
        locale=locale if isinstance(locale, str) else "",
        context=context if isinstance(context, str) else "",
    ), segment_id


def _call_rater(rater, segment):
    for name in _RATER_METHODS:
        method = getattr(rater, name, None)
        if callable(method):
            return method(segment)
    if callable(rater):
        return rater(segment)
    raise TypeError(f"rater {rater!r} has no callable review method")


def _field(raw, name):
    if isinstance(raw, Mapping):
        return raw.get(name)
    return getattr(raw, name, None)


def _parse_verdict(raw):
    """Normalise a rater response. Return (verdict, confidence, hard_issue) or None if unusable."""
    if raw is None:
        return None

    hard = _field(raw, "hard_issue")
    hard_issue = hard is True or (isinstance(hard, str) and hard.strip().lower() == "true")
    if hard_issue:
        # Honour a hard issue even if the rest of the payload is broken.
        return ("reject", 1.0, True)

    verdict = _field(raw, "verdict")
    if not isinstance(verdict, str):
        return None
    verdict = verdict.strip().lower()
    if verdict in _APPROVE_WORDS:
        verdict = "approve"
    elif verdict in _REJECT_WORDS:
        verdict = "reject"
    else:
        return None

    confidence = _field(raw, "confidence")
    if isinstance(confidence, bool) or not isinstance(confidence, (int, float)):
        return None
    if math.isnan(confidence) or confidence < 0 or confidence > 1:
        return None
    return (verdict, float(confidence), False)


def _step_name(rater):
    """Trace step name, e.g. 'accuracy', 'localization_policy'."""
    dimension = getattr(rater, "dimension", None)
    if _is_text(dimension):
        return dimension.strip()
    cls = type(rater).__name__
    if cls.endswith("Rater") and len(cls) > len("Rater"):
        return re.sub(r"(?<!^)(?=[A-Z])", "_", cls[: -len("Rater")]).lower()
    for attr in ("name", "rater_id"):
        value = getattr(rater, attr, None)
        if _is_text(value):
            return value.strip()
    return cls.lower()
