import os
from openai import OpenAI


class LLMClient:

    def __init__(self, model=None):
        self._base_url = os.environ.get('OPENAI_BASE_URL')
        self._model = model or os.environ.get('OPENAI_MODEL', 'gpt-4o-mini')
        self._client = None

    def complete(self, rater_id, segment_id, prompt):
        if self._client is None:
            self._client = OpenAI(base_url=self._base_url)
        response = self._client.chat.completions.create(
            model=self._model,
            messages=[{'role': 'user', 'content': prompt}],
            temperature=0,
        )
        return response.choices[0].message.content
