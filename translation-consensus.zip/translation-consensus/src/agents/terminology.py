from src.agents.base import BaseRater


class TerminologyRater(BaseRater):
    """Checks whether domain and brand terminology is used correctly."""
    dimension = "terminology"
