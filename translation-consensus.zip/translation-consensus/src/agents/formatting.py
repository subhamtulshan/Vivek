from src.agents.base import BaseRater


class FormattingRater(BaseRater):
    """Checks that placeholders, tags, and layout are preserved."""
    dimension = "formatting"
