from src.agents.base import BaseRater


class LocalizationPolicyRater(BaseRater):
    """Checks the translation against locale-specific policy requirements."""
    dimension = "localization_policy"
