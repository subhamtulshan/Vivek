from src.agents.base import BaseRater


class AccuracyRater(BaseRater):
    """Checks whether the translation preserves the source segment's meaning."""
    dimension = "accuracy"
