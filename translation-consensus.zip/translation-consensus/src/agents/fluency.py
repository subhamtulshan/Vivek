from src.agents.base import BaseRater


class FluencyRater(BaseRater):
    """Checks whether the translation reads naturally in the target language."""
    dimension = "fluency"
