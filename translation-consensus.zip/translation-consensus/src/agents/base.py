"""Base class for the specialist raters (reconstruction; the exam's src/agents may differ).

Each rater fills its prompt template, calls the LLM, and parses the JSON reply
into a RaterVerdict. Transport failures become a transient RaterUnavailableError.
An unparseable reply returns None (a "missing response").
"""
import json
from pathlib import Path

from src.models import RaterUnavailableError, RaterVerdict

PROMPTS_DIR = Path(__file__).resolve().parents[2] / "prompts"


class BaseRater:
    dimension = "base"

    def __init__(self, llm, rater_id=None):
        self._llm = llm
        self.rater_id = rater_id or f"{self.dimension}_rater"

    def _prompt(self, segment):
        template = (PROMPTS_DIR / f"{self.dimension}.txt").read_text(encoding="utf-8")
        return template.format(
            source_text=segment.source_text,
            translation_text=segment.translation_text,
            locale=segment.locale,
            context=segment.context,
        )

    def review(self, segment):
        try:
            raw = self._llm.complete(self.rater_id, segment.segment_id, self._prompt(segment))
        except RaterUnavailableError:
            raise
        except Exception as exc:  # network / timeout / rate limit
            raise RaterUnavailableError(f"{self.rater_id}: {exc}", transient=True) from exc
        try:
            data = json.loads(raw)
            return RaterVerdict(
                rater_id=self.rater_id,
                dimension=self.dimension,
                verdict=str(data["verdict"]),
                confidence=float(data["confidence"]),
                hard_issue=bool(data.get("hard_issue", False)),
            )
        except (TypeError, ValueError, KeyError):
            return None
