# Reconstructed from the exam screenshots (src/models.py) so the solution can run locally.
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Reason(str, Enum):
    QUORUM_APPROVE = 'QUORUM_APPROVE'
    QUORUM_REJECT = 'QUORUM_REJECT'
    HARD_ISSUE = 'HARD_ISSUE'
    NO_QUORUM = 'NO_QUORUM'
    INSUFFICIENT_RATERS = 'INSUFFICIENT_RATERS'


class ErrorCode(str, Enum):
    INVALID_REQUEST = 'INVALID_REQUEST'


class RaterUnavailableError(Exception):

    def __init__(self, message, transient=True):
        super().__init__(message)
        self.transient = transient


@dataclass
class ConsensusConfig:
    panel_size: int = 5
    approve_quorum: int = 3
    reject_quorum: int = 3
    min_confidence: float = 0.6
    max_retries: int = 1


@dataclass
class SegmentRef:
    segment_id: str
    source_text: str
    translation_text: str
    locale: str = ''
    context: str = ''


@dataclass
class RaterVerdict:
    rater_id: str
    dimension: str
    verdict: str
    confidence: float
    hard_issue: bool = False


@dataclass
class VoteSummary:
    approvals: int = 0
    rejections: int = 0
    abstained_unavailable: int = 0
    hard_issues: int = 0


@dataclass
class TraceEvent:
    step: str
    attempt: int
    status: str


@dataclass
class ConsensusDecision:
    segment_id: Optional[str]
    status: str
    vote_summary: Optional[VoteSummary]
    reason: Optional[str]
    error: Optional[str]
    trace: list = field(default_factory=list)


class AgentRegistry:

    def __init__(self, accuracy=None, terminology=None, fluency=None,
                 localization_policy=None, formatting=None):
        self._raters = [accuracy, terminology, fluency, localization_policy, formatting]

    def panel(self):
        return [rater for rater in self._raters if rater is not None]
