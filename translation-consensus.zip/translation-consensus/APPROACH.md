# APPROACH

## Flow
1. **Validate**: `segment_id`, `source_text` and `translation_text` must be non-blank strings.
   If not, return `status="error"`, `error="INVALID_REQUEST"`, `vote_summary=None`, `reason=None`, `trace=[]`.
   No rater is called.
2. **Ask raters in order** (`AgentRegistry.panel()`). Each rater gets `1 + max_retries` attempts.
   Each attempt adds one `TraceEvent(step, attempt, status)`.
3. **Hard issue**: return `blocked / HARD_ISSUE` at once. Raters after it are never called.
4. **Tally**: only votes with `confidence >= min_confidence` count.
5. **Decide**: approve or reject on quorum. If both quorums or neither are reached, escalate:
   `INSUFFICIENT_RATERS` when fewer raters answered than the smaller quorum, otherwise `NO_QUORUM`.

## Assumptions
- Statuses: `approved | rejected | blocked | escalated | error`.
- Trace statuses: `success | unavailable | error | missing`.
- Only `RaterUnavailableError` with `transient=True` is retried. `transient=False` means a permanent outage and is not retried.
- Other exceptions, a `None` reply, or a malformed verdict (unknown verdict, confidence that is non-numeric, NaN, bool or
  outside [0, 1]) count as one attempt and are not retried. All of these raise `abstained_unavailable`.
- A hard issue blocks **regardless of confidence**. This is fail-safe for sensitive content such as medical disclaimers.
- If both quorums are reached (possible with small quorums), there is no single winner, so the segment is escalated, not approved.
- `abstained_unavailable` counts raters with no usable answer. Low-confidence voters did answer, so they are not counted there.
- Bad config is clamped, not rejected: quorum >= 1 (quorum 0 would approve with zero votes) and `max_retries >= 0`.

## Tradeoffs
- Raters run one after another so the hard-issue short-circuit stops real work. Running them in parallel would lower latency
  but waste calls and make "only attempts that actually ran" unclear.
- A per-rater failure never fails the whole segment. Only an internal or registry failure returns `status="error"`.

## Failure modes
- Very large `max_retries` combined with an always-down rater makes a long loop and a large trace.
- Retries have no backoff or jitter, so a struggling LLM endpoint gets hit again immediately.
- If a rater hangs, there is no timeout. The rater or LLM client has to enforce one.

## For production
- Exponential backoff with jitter, a per-call timeout, a total deadline per segment, and a circuit breaker for each rater.
- Structured logs and metrics (latency, retries, escalation rate per locale and dimension).
- Per-locale or per-content-type policies (for example, stricter quorum for medical or legal text) and idempotency keys.
- Parallel fan-out with cancellation once a hard issue is seen.
