# Translation Quality Consensus Workflow

An orchestrator for Lingua Bridge that combines a panel of five specialist rater agents' per-dimension
votes into a single sign-off decision for a translated segment.

Implement the `ConsensusWorkflow` constructor and `review()` in `src/consensus_workflow.py`.

## Install
    bash install.sh

## Test
    bash tests.sh

You can add your own test cases to `tests/test_scratch.py` or create a new file under `tests/`.

## Run the app
    streamlit run app.py --server.port 8000
